package Controlador;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class PruebaController implements Initializable {

    @FXML
    private ImageView carruselImage;

    private List<Image> imagenes;
    private int indiceActual = 0;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        imagenes = List.of(
    new Image(getClass().getResource("/images/img1.png").toExternalForm()),
    new Image(getClass().getResource("/images/img2.png").toExternalForm()),
    new Image(getClass().getResource("/images/img3.png").toExternalForm()),
    new Image(getClass().getResource("/images/img4.png").toExternalForm()),
    new Image(getClass().getResource("/images/img5.png").toExternalForm())
);

        // Mostrar primera imagen
        carruselImage.setImage(imagenes.get(0));
        URL url = getClass().getResource("images/img1.png");
System.out.println("Ruta encontrada: " + url);
   

        // Crear Timeline que cambia la imagen cada 3 segundos
        Timeline timeline = new Timeline(
            new KeyFrame(Duration.seconds(3), event -> cambiarImagen())
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void cambiarImagen() {
        indiceActual = (indiceActual + 1) % imagenes.size();
        carruselImage.setImage(imagenes.get(indiceActual));
             for (Image img : imagenes) {
    System.out.println("Imagen cargada: " + img.getUrl());
}
    }
    
}