package Controlador;

import Modelos.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.stage.*;
import java.io.*;
import java.net.URL;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.scene.*;
import javafx.fxml.Initializable;



public class ControlaAgregar implements Initializable {

    @FXML private TextField txtNombre;
    @FXML private TextField txtDescripcion;
    @FXML private TextField txtPrecio;
    @FXML private TextField txtCantidad;
    @FXML private Button btnCargarImagen;
    @FXML private ImageView imageView;
    @FXML private Button btnAgregar;
    @FXML private Button Atras;
    @FXML private Button Catalog;
    

    private File imagenSeleccionada;
    
    

    @FXML
    void seleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar imagen del producto");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg")
        );
        imagenSeleccionada = fileChooser.showOpenDialog(new Stage());
        if (imagenSeleccionada != null) {
            Image image = new Image(imagenSeleccionada.toURI().toString());
            imageView.setImage(image);
        }
    }

    @FXML
    void agregarProducto(ActionEvent event) {
    String nombre = txtNombre.getText();
    String descripcion = txtDescripcion.getText();
    String precioTexto = txtPrecio.getText().replace(".", "");
    String cantidadTexto = txtCantidad.getText();

    int precio, cantidad;

    try {
        precio = Integer.parseInt(precioTexto);
        cantidad = Integer.parseInt(cantidadTexto);
    } catch (NumberFormatException e) {
        mostrarAlerta("Error", "Precio o cantidad no válido");
        return;
    }

    if (nombre.isEmpty() || imagenSeleccionada == null) {
        mostrarAlerta("Error", "Debe llenar todos los campos y seleccionar una imagen.");
        return;
    }

    Productoc productoc = new Productoc(nombre, descripcion, imagenSeleccionada.toURI().toString(), cantidad, precio);
    GestorProductos.getInstance().agregarProducto(productoc);
    mostrarAlerta("Éxito", "Producto agregado correctamente.");
    limpiarCampos();
}

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtDescripcion.clear();
        txtPrecio.clear();
        txtCantidad.clear();
        imageView.setImage(null);
        imagenSeleccionada = null;
    }

    @FXML
    void volverAtras(ActionEvent event) {
cambiarEscena(event, "/fxml/PerfilAdm.fxml");
    }
    
    @FXML
private void irCatalogo(ActionEvent event) {
    cambiarEscena(event, "/fxml/CatalogoAdm.fxml");
}

private void cambiarEscena(ActionEvent event, String rutaFXML) {
    try {
        URL fxmlUrl = getClass().getResource(rutaFXML);
        if (fxmlUrl == null) {
            System.out.println("No se encontró el archivo FXML: " + rutaFXML);
            return;
        }

        FXMLLoader loader = new FXMLLoader(fxmlUrl);
        Parent root = loader.load();

       
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    } catch (IOException e) {
        System.out.println("Error al cargar FXML: " + rutaFXML);
        e.printStackTrace();
    }
}

@Override
public void initialize(URL url, ResourceBundle rb) {
    txtPrecio.focusedProperty().addListener((obs, oldVal, newVal) -> {
        if (!newVal) {
            String texto = txtPrecio.getText().replace(".", "");
            if (!texto.isEmpty()) {
                try {
                    int valor = Integer.parseInt(texto);
                    NumberFormat formato = NumberFormat.getInstance(new Locale("es", "CO"));
                    txtPrecio.setText(formato.format(valor));
                } catch (NumberFormatException e) {
                    txtPrecio.setText("");
                }
            }
        }
    });
}
}


