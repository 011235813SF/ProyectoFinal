/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import javafx.scene.control.Alert;

/**
 *
 * @author PC
 */
public class Controlafav {

    private static Controlafav instancia;

    public static Controlafav getInstancia() {
        if (instancia == null) {
            instancia = new Controlafav();
        }
        return instancia;
    }

    public nodo<Productoc> cab;

    public boolean getVacia() {
        return cab == null ? true : false;
    }

    public void agregarFavorito(Productoc producto) {
        if (yaExiste(producto.nombreprod)) {
            mostrarError("Este producto ya está en la lista de favoritos.");
            return;
        }

        nodo<Productoc> nuevo = new nodo<>(producto);

        if (getVacia()) {
            cab = nuevo;
            cab.sig = cab;
            cab.ant = cab;
        } else {
            nodo<Productoc> ultimo = cab.ant;
            nuevo.sig = cab;
            nuevo.ant = ultimo;
            cab.ant = nuevo;
            ultimo.sig = nuevo;
        }
    }

    public boolean yaExiste(String nombreprod) {
        if (getVacia()) return false;

        nodo<Productoc> actual = cab;
        do {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombreprod)) {
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public boolean eliminarFavorito(String nombreprod) {
        if (getVacia()) return false;

        nodo<Productoc> actual = cab;
        do {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombreprod)) {
                if (actual == cab && cab.sig == cab) {
                    cab = null;
                } else {
                    actual.ant.sig = actual.sig;
                    actual.sig.ant = actual.ant;
                    if (actual == cab) {
                        cab = actual.sig;
                    }
                }
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public int contarFavoritos() {
        if (getVacia()) return 0;

        int contador = 0;
        nodo<Productoc> actual = cab;
        do {
            contador++;
            actual = actual.sig;
        } while (actual != cab);

        return contador;
    }

    public void vaciarFavoritos() {
        cab = null;
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}

