/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Modelos.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Camila
 */
public class GestorProductos { 


    private static final GestorProductos instancia = new GestorProductos();
    private final List<Productoc> productos = new ArrayList<>();

    private GestorProductos() {}

    public static GestorProductos getInstance() {
        return instancia;
    }

    public void agregarProducto(Productoc producto) {
        productos.add(producto);
    }

    public List<Productoc> obtenerProductos() {
        return productos;
    }
}
