/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Modelos.*;
import javafx.fxml.FXML;
import javafx.scene.layout.GridPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

/**
 *
 * @author Camila
 */
public class ControlaCatalogoC {
     @FXML private GridPane grid;

    @FXML
    public void initialize() {
        mostrarProductos();
    }

    private void mostrarProductos() {
        grid.getChildren().clear();
        int col = 0, row = 0;
        for (Productoc p : GestorProductos.getInstance().obtenerProductos()) {
            VBox card = new VBox(5);
            ImageView img = new ImageView(new Image(p.rutaimg));
            img.setFitWidth(100);
            img.setFitHeight(100);
            Button btnFavorito = new Button("❤");
            Button btnCarrito = new Button("🛒");
            card.getChildren().addAll(new Label(p.nombreprod), img, btnFavorito, btnCarrito);
            grid.add(card, col++, row);
            if (col == 3) { col = 0; row++; }
        }
    }
}
