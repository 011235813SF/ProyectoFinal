/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Modelos.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
/**
 *
 * @author Camila
 */
public class ControlaAgregar {

    @FXML private TextField txtNombre;
    @FXML private TextField txtDescripcion;
    @FXML private TextField txtPrecio;
    @FXML private TextField txtCantidad;
    @FXML private Button btnCargarImagen;
    @FXML private ImageView imageView;
    @FXML private Button btnAgregar;

    private File imagenSeleccionada;

    @FXML
    void seleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar imagen del producto");
        fileChooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg")
        );
        imagenSeleccionada = fileChooser.showOpenDialog(new Stage());
        if (imagenSeleccionada != null) {
            Image image = new Image(imagenSeleccionada.toURI().toString());
            imageView.setImage(image);
        }
    }

    @FXML
    void agregarProducto(ActionEvent event) {
        String nombre = txtNombre.getText();
        String descripcion = txtDescripcion.getText();
        int precio;
        int cantidad;

        try {
            precio = Integer.parseInt(txtPrecio.getText());
            cantidad = Integer.parseInt(txtCantidad.getText());
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "Precio o cantidad no válido");
            return;
        }

        if (nombre.isEmpty() || imagenSeleccionada == null) {
            mostrarAlerta("Error", "Debe llenar todos los campos y seleccionar una imagen.");
            return;
        }

        Productoc productoc = new Productoc(nombre, descripcion, imagenSeleccionada.toURI().toString(), cantidad, precio);
        GestorProductos.getInstance().agregarProducto(productoc);
        mostrarAlerta("Éxito", "Producto agregado correctamente.");
        limpiarCampos();
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtPrecio.clear();
        txtCantidad.clear();
        imageView.setImage(null);
        imagenSeleccionada = null;
    }
}


