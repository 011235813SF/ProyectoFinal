/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import javafx.scene.control.Alert;

/**
 *
 * @author PC
 */
public class Controlacarrito {

    private static Controlacarrito instancia;

    public static Controlacarrito getInstancia() {
        if (instancia == null) {
            instancia = new Controlacarrito();
        }
        return instancia;
    }

    private Controlacarrito() {
        cab = null;
    }

    public nodo<Carrito> cab;

     public boolean getVacia() {
        return cab == null ? true : false;
    }


    public void agregarCarrito(Carrito item) {
        if (!getVacia()) {
            nodo<Carrito> actual = cab;
            do {
                if (actual.dato.producto.nombreprod.trim().equalsIgnoreCase(item.producto.nombreprod.trim())) {
                    mostrarError("Error: El producto ya está en el carrito");
                    return;
                }
                actual = actual.sig;
            } while (actual != cab);
        }

        nodo<Carrito> nuevo = new nodo<>(item);

        if (getVacia()) {
            cab = nuevo;
            cab.sig = cab;
            cab.ant = cab;
        } else {
            nodo<Carrito> ultimo = cab.ant;

            nuevo.sig = cab;
            nuevo.ant = ultimo;

            cab.ant = nuevo;
            ultimo.sig = nuevo;
        }
    }
    
    public double getTotal() {
    if (getVacia()) return 0;

    double total = 0;
    nodo<Carrito> actual = cab;
    do {
        total += actual.dato.getSubtotal();
        actual = actual.sig;
    } while (actual != cab);

    return total;
}


    public boolean actualizarCantidad(String nombre, int nuevaCantidad) {
        if (getVacia()) return false;

        nodo<Carrito> actual = cab;
        do {
            if (actual.dato.producto.nombreprod.trim().equalsIgnoreCase(nombre.trim())) {
                actual.dato.cant = nuevaCantidad;
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public boolean eliminar(String nombreprod) {
        if (getVacia()) return false;

        nodo<Carrito> actual = cab;
        do {
            if (actual.dato.producto.nombreprod.trim().equalsIgnoreCase(nombreprod.trim())) {
                if (actual == cab && cab.sig == cab) {
                    cab = null;
                } else {
                    actual.ant.sig = actual.sig;
                    actual.sig.ant = actual.ant;
                    if (actual == cab) {
                        cab = actual.sig;
                    }
                }
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public int contarElementos() {
        if (getVacia()) return 0;

        int contador = 0;
        nodo<Carrito> actual = cab;
        do {
            contador++;
            actual = actual.sig;
        } while (actual != cab);

        return contador;
    }

    public void Vaciar() {
        cab = null;
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}
