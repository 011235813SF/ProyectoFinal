/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.time.LocalDateTime;
import java.time.YearMonth;

public class Pedido {
    public String direccionEnvio;
    public String tipoPago; // "Efectivo" o "Tarjeta"
    public String numeroTarjeta; // Solo si aplica
    public String nombreTitular;
    public YearMonth fechaVencimientoTarjeta; // Mes y año
    public LocalDateTime fechaPedido; // Fecha del sistema
    public String resumenArticulos; // Nombre y cantidad de productos
    public double subtotal;
    public double envio;
    public double total;

    public Pedido(String direccionEnvio, String tipoPago, String numeroTarjeta, String nombreTitular,
                  YearMonth fechaVencimientoTarjeta, String resumenArticulos,
                  double subtotal, double envio, double total) {

        this.direccionEnvio = direccionEnvio;
        this.tipoPago = tipoPago;
        this.numeroTarjeta = numeroTarjeta;
        this.nombreTitular = nombreTitular;
        this.fechaVencimientoTarjeta = fechaVencimientoTarjeta;

        this.fechaPedido = LocalDateTime.now(); // Fecha actual del sistema

        this.resumenArticulos = resumenArticulos;
        this.subtotal = subtotal;
        this.envio = envio;
        this.total = total;
    }

    @Override
public String toString() {
    return resumenArticulos + "||" + total + "||" + direccionEnvio + "||" +
           tipoPago + "||" + (fechaPedido != null ? fechaPedido.toString() : "Sin fecha");
}

}
