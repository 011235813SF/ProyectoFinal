/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Controlador;

import Modelos.Direcciones;
import Modelos.nodo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

public class Controladirecc {
    
     private static Controladirecc instancia;

    public static Controladirecc getInstancia() {
        if (instancia == null) {
            instancia = new Controladirecc();
        }
        return instancia;
    }




    private static nodo<Direcciones> cab=null;
    private String correoUsuario;

    public void setCorreoUsuario(String correo) {
        this.correoUsuario = correo;
    }

 

    
    public boolean AddDireccion(TextField dirEntrega, TextField departamento, TextField municipio,
                             TextField barrio, TextField apto, TextField indicaciones,
                             ToggleGroup tipoGrupo, TextField contacto, TextField telContacto) {
    try {
        // Validación de campos obligatorios
        if (dirEntrega.getText().trim().isEmpty() ||
            departamento.getText().trim().isEmpty() ||
            municipio.getText().trim().isEmpty() ||
            barrio.getText().trim().isEmpty() ||
            contacto.getText().trim().isEmpty() ||
            telContacto.getText().trim().isEmpty()) {
            
            Controlausuarios.getInstancia().mostrarError("¡Error! Debe llenar todos los campos obligatorios.");
            return false;
        }

        // Validación del tipo de domicilio seleccionado
        Toggle selectedToggle = tipoGrupo.getSelectedToggle();
        if (selectedToggle == null) {
            Controlausuarios.getInstancia().mostrarError("Debe seleccionar el tipo de domicilio.");
            return false;
        }

        String tipo = ((RadioButton) selectedToggle).getText();

        // Validación del teléfono
        if (!telContacto.getText().trim().matches("\\d+")) {
            Controlausuarios.getInstancia().mostrarError("El teléfono de contacto solo debe contener números.");
            telContacto.requestFocus();
            return false;
        }

        // Crear nueva dirección
        Direcciones nueva = new Direcciones(
                dirEntrega.getText().trim(),
                departamento.getText().trim(),
                municipio.getText().trim(),
                barrio.getText().trim(),
                apto.getText().trim(),
                indicaciones.getText().trim(),
                tipo,
                contacto.getText().trim(),
                telContacto.getText().trim()
        );

        // Agregar y guardar
        agregarDireccion(nueva);

        // Mostrar mensaje de éxito
        mostrarMensaje("Dirección guardada correctamente");
        return true;

    } catch (Exception e) {
        Controlausuarios.getInstancia().mostrarError("Error al agregar dirección: " + e.getMessage());
        return false;
    }
}

   
public void mostrarMensaje(String texto) {
    Alert alerta = new Alert(Alert.AlertType.INFORMATION);
    alerta.setTitle("Información");
    alerta.setHeaderText(null);
    alerta.setContentText(texto);
    alerta.showAndWait();
}



   
    public void agregarDireccion(Direcciones nueva) {
    nodo<Direcciones> nuevoNodo = new nodo<>(nueva);
    if (cab == null) {
        cab = nuevoNodo;
    } else {
        nodo<Direcciones> p = cab;
        while (p.sig != null) {
            p = p.sig;
        }
        p.sig = nuevoNodo;
        nuevoNodo.ant = p;
    }
  
}


    private void agregarDireccionSinGuardar(Direcciones nueva) {
        nodo<Direcciones> nuevoNodo = new nodo<>(nueva);
        if (cab == null) {
            cab = nuevoNodo;
        } else {
            nodo<Direcciones> p = cab;
            while (p.sig != null) {
                p = p.sig;
            }
            p.sig = nuevoNodo;
            nuevoNodo.ant = p;
        }
    }

  

    private String obtenerRutaUsuario() {
        if (correoUsuario == null || correoUsuario.isEmpty()) {
            correoUsuario = Controlausuarios.getInstancia().getUsuarioActual().correo;
        }
        return "direcciones_" + correoUsuario.replace("@", "_").replace(".", "_") + ".txt";
    }

    @FXML
    private void volverAtras(ActionEvent event) {
        cambiarEscena(event, "/fxml/Carrito.fxml");
    }

    @FXML
    private void iraMetPago(ActionEvent event) {
        cambiarEscena(event, "fxml/MediosdePago.fxml");
    }
    
      @FXML private TextField dirEntrega;
    @FXML private TextField departamento;
    @FXML private TextField municipio;
    @FXML private TextField barrio;
    @FXML private TextField apto;
    @FXML private TextField indicaciones;
    @FXML private TextField contacto;
    @FXML private TextField telContacto;
    @FXML private RadioButton residencial;
    @FXML private RadioButton laboral;
    @FXML private ToggleGroup grupoTipo;

    @FXML
    public void initialize() {
        grupoTipo = new ToggleGroup();
        residencial.setToggleGroup(grupoTipo);
        laboral.setToggleGroup(grupoTipo);
    }



    @FXML
    private void guardarYRegresar(ActionEvent event) {
        boolean guardado = Controladirecc.getInstancia().AddDireccion(
                dirEntrega, departamento, municipio, barrio, apto,
                indicaciones, grupoTipo, contacto, telContacto
        );
        if (guardado) {
            cambiarEscena(event,"/fxml/MediosdePago.fxml");
        }
    }
    
 @FXML
  private void cambiarEscena(ActionEvent event, String rutaFXML) {
    try {
        // Debug: imprimir la ruta para verificar que no sea null
        System.out.println("Cargando FXML desde: " + rutaFXML);
        
        URL fxmlLocation = getClass().getResource(rutaFXML);
        if (fxmlLocation == null) {
            throw new IOException("FXML no encontrado: " + rutaFXML);
        }

        FXMLLoader loader = new FXMLLoader(fxmlLocation);
        Parent root = loader.load();
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
        mostrarError("No se pudo cargar la ventana:\n" + e.getMessage());
    }
    
}
  private void mostrarError(String mensaje) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle("Error");
    alert.setHeaderText("No se pudo cargar la ventana");
    alert.setContentText(mensaje);
    alert.showAndWait();
}



    
    public Direcciones getUltimaDireccion() {
    nodo<Direcciones> temp = cab;
    if (temp == null) return null;
    while (temp.sig != null) {
        temp = temp.sig;
    }
    return temp.dato;
}

@FXML private ImageView logoImageView;
    public void initialize(URL location, ResourceBundle resources) {
        Controlacarrito.getInstancia().setUsuarioActual(Controlausuarios.getInstancia().getUsuarioActual());


        URL logoUrl = getClass().getResource("/images/Logo.png");
        if (logoUrl != null && logoImageView != null) {
            logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        }
    }


}

