/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ControlaCompras {

    @FXML
    private VBox contenedorResumen;

    @FXML
    public void initialize() {
        cargarHistorialDesdeArchivo();
    }

    private void cargarHistorialDesdeArchivo() {
        contenedorResumen.getChildren().clear();
        String correo = Controlausuarios.getInstancia().getUsuarioActual().correo;
        String rutaArchivo = "pedidos_" + correo + ".txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split("\\|\\|");
                if (partes.length == 5) {
                    VBox tarjeta = crearTarjetaCompra(partes);
                    contenedorResumen.getChildren().add(tarjeta);
                }
            }
        } catch (IOException e) {
            Label sinPedidos = new Label("No se encontraron pedidos registrados.");
            sinPedidos.setStyle("-fx-font-size: 16px; -fx-text-fill: #555;");
            contenedorResumen.getChildren().add(sinPedidos);
        }
    }

    private VBox crearTarjetaCompra(String[] partes) {
        Label resumen = new Label("🛍 Resumen: " + partes[0]);
        Label total = new Label("💰 Total: $" + partes[1]);
        Label direccion = new Label("📍 Dirección: " + partes[2]);
        Label tipoPago = new Label("💳 Pago: " + partes[3]);
        Label fecha = new Label("📅 Fecha de pedido: " + partes[4]);

        resumen.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        total.setStyle("-fx-font-size: 14px;");
        direccion.setStyle("-fx-font-size: 14px;");
        tipoPago.setStyle("-fx-font-size: 14px;");
        fecha.setStyle("-fx-font-size: 14px;");

        VBox tarjeta = new VBox(8, resumen, total, direccion, tipoPago, fecha);
        tarjeta.setStyle("""
            -fx-background-color: #ffffff;
            -fx-border-color: #cccccc;
            -fx-border-radius: 10;
            -fx-background-radius: 10;
            -fx-padding: 15;
            -fx-effect: dropshadow(three-pass-box, rgba(0,0,0,0.2), 8, 0, 0, 4);
        """);
        tarjeta.setPrefWidth(720);
        return tarjeta;
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void volerAtras(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    @FXML
    private void IrAtrasCompras(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoC.fxml");
    }

    @FXML
    private void IrAtrasAPerfil(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    @FXML
    private void IrAFavoritos(ActionEvent event) {
        cambiarEscena(event, "/fxml/ListaDeseos.fxml");
    }

    @FXML
    private void IrACarrito(ActionEvent event) {
        cambiarEscena(event, "/fxml/Carrito.fxml");
    }
    
    @FXML private ImageView logoImageView;
    public void initialize(URL location, ResourceBundle resources) {
        Controlacarrito.getInstancia().setUsuarioActual(Controlausuarios.getInstancia().getUsuarioActual());


        URL logoUrl = getClass().getResource("/images/Logo.png");
        if (logoUrl != null && logoImageView != null) {
            logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        }
    }
}
