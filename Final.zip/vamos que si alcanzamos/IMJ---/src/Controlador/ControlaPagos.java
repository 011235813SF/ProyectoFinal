/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.io.BufferedWriter;
import java.io.FileWriter;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.event.ActionEvent;
import javafx.util.StringConverter;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ControlaPagos {

    @FXML private RadioButton rbEfectivo;
    @FXML private RadioButton rbTarjeta;
    @FXML private TextField txtNumTarjeta;
    @FXML private TextField txtNomTitular;
    @FXML private DatePicker txtFechaVenc;
    @FXML private Button btnFinalizar;

    private ToggleGroup grupoTipo;
    private static ControlaPagos instancia;

    public static ControlaPagos getInstancia() {
        if (instancia == null) instancia = new ControlaPagos();
        return instancia;
    }

    @FXML
    public void initialize() {
        grupoTipo = new ToggleGroup();
        rbEfectivo.setToggleGroup(grupoTipo);
        rbTarjeta.setToggleGroup(grupoTipo);
        rbEfectivo.setSelected(true);
        actualizarCamposTarjeta(false);

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yyyy");
        txtFechaVenc.setPromptText("MM/yyyy");

        txtFechaVenc.setConverter(new StringConverter<LocalDate>() {
            @Override
            public String toString(LocalDate date) {
                return (date != null) ? formatter.format(date) : "";
            }

            @Override
            public LocalDate fromString(String string) {
                try {
                    if (string != null && !string.isEmpty()) {
                        YearMonth ym = YearMonth.parse(string, formatter);
                        return ym.atDay(1);
                    }
                } catch (DateTimeParseException e) {
                    return null;
                }
                return null;
            }
        });

        txtFechaVenc.setDayCellFactory(picker -> new DateCell() {
            @Override
            public void updateItem(LocalDate date, boolean empty) {
                super.updateItem(date, empty);
                setDisable(true);
            }
        });

        grupoTipo.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
            actualizarCamposTarjeta(rbTarjeta.isSelected());
        });
    }

    private void actualizarCamposTarjeta(boolean habilitar) {
        txtNumTarjeta.setDisable(!habilitar);
        txtNomTitular.setDisable(!habilitar);
        txtFechaVenc.setDisable(!habilitar);
    }

    @FXML
    private void finalizarPago(ActionEvent event) {
        if (rbTarjeta.isSelected()) {
            String numeroTarjeta = txtNumTarjeta.getText().trim();
            String nombreTitular = txtNomTitular.getText().trim();
            LocalDate fecha = txtFechaVenc.getValue();

            if (numeroTarjeta.isEmpty() || nombreTitular.isEmpty() || fecha == null) {
                mostrarMensaje("Por favor, completa todos los campos de la tarjeta.");
                return;
            }
        }

        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmar pedido");
        alert.setHeaderText("¿Deseas confirmar este pedido?");
        alert.setContentText("Esta acción no se puede deshacer.");

        Optional<ButtonType> resultado = alert.showAndWait();
        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {

            guardarPedido();
            Controlacarrito.getInstancia().vaciarCarrito();
            mostrarMensaje("Pedido registrado correctamente.");
            cambiarEscena("/fxml/Compras.fxml", btnFinalizar);
        } else {
            mostrarMensaje("Pedido cancelado.");
            cambiarEscena("/fxml/Carrito.fxml", btnFinalizar);
        }
    }

    private void guardarPedido() {
        String correo = Controlausuarios.getInstancia().getUsuarioActual().correo;
        String rutaArchivo = "pedidos_" + correo + ".txt";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo, true))) {

            // Aquí deberías obtener los datos REALES del carrito:
            String resumen = "Productos del carrito";
            String total = "123.45";  // TODO: Obtener el total real del carrito
            String direccion = "Calle 123";  // TODO: Obtener dirección del usuario
            String tipoPago = rbTarjeta.isSelected() ? "Tarjeta" : "Efectivo";
            String fecha = LocalDate.now().toString();

            String linea = resumen + "||" + total + "||" + direccion + "||" + tipoPago + "||" + fecha;
            writer.write(linea);
            writer.newLine();

        } catch (IOException e) {
            mostrarMensaje("Error al guardar el pedido: " + e.getMessage());
        }
    }

    private void cambiarEscena(String rutaFXML, Control control) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) control.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            mostrarMensaje("No se pudo cargar la escena: " + e.getMessage());
        }
    }

    private void mostrarMensaje(String texto) {
        Alert alerta = new Alert(AlertType.INFORMATION);
        alerta.setTitle("Información");
        alerta.setContentText(texto);
        alerta.showAndWait();
    }
    
    @FXML private ImageView logoImageView;
    public void initialize(URL location, ResourceBundle resources) {
        Controlacarrito.getInstancia().setUsuarioActual(Controlausuarios.getInstancia().getUsuarioActual());


        URL logoUrl = getClass().getResource("/images/Logo.png");
        if (logoUrl != null && logoImageView != null) {
            logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        }
    }
}