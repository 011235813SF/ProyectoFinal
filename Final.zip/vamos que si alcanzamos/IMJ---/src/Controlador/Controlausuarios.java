/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import javafx.scene.control.*;
import java.util.regex.*;
import java.io.*;

public class Controlausuarios {
    private static Controlausuarios instancia;

    public static Controlausuarios getInstancia() {
        if (instancia == null) {
            instancia = new Controlausuarios();
        }
        return instancia;
    }

    public nodo<Usuarios> cab;
    public Usuarios usuarioActual;

    public Usuarios getUsuarioActual() {
        return usuarioActual;
    }

    public void setUsuarioActual(Usuarios usuarioActual) {
        this.usuarioActual = usuarioActual;

        // Configura Controladirecc con el correo del usuario actual
        Controladirecc.getInstancia().setCorreoUsuario(usuarioActual.correo);
        
    }

    public Controlausuarios() {
        cab = null;
        cargarUsuariosDesdeArchivo("usuarios.txt");
        agregarUsuarioManual();
        // No cargar direcciones aquí
    }

    public void agregarUsuarioManual() {
        String correoAdmin = "isa@gmail.com";
        String correoCliente = "isav@gmail.com";

        if (BuscarUsuario(correoAdmin) == null) {
            Usuarios usuario1 = new Usuarios("Isabela", "Valdés", "admin", correoAdmin, "1234567890", "12345678");
            Agregarusuario(usuario1);
        }

        if (BuscarUsuario(correoCliente) == null) {
            Usuarios usuario2 = new Usuarios("Isabela", "Valdés", "cliente", correoCliente, "1234567890", "12345678");
            Agregarusuario(usuario2);
        }
    }

    public boolean getVacia() {
        return cab == null;
    }

    public nodo<Usuarios> BuscarUsuario(String corr) {
        nodo<Usuarios> p = cab;
        while (p != null) {
            if (p.dato.correo.equalsIgnoreCase(corr)) {
                return p;
            }
            p = p.sig;
        }
        return null;
    }

    public boolean AddUsuario(TextField nomb, TextField apell, TextField corr, TextField tel, TextField cont) {
        try {
            if (nomb.getText().trim().isEmpty() || apell.getText().trim().isEmpty() ||
                corr.getText().trim().isEmpty() || tel.getText().trim().isEmpty() || cont.getText().trim().isEmpty()) {
                mostrarError("Debe llenar todos los campos.");
                return false;
            }

            String telefono = tel.getText().trim();
            if (!telefono.matches("\\d+")) {
                mostrarError("El teléfono solo debe contener números");
                tel.setText("");
                tel.requestFocus();
                return false;
            }

            String correo = corr.getText().trim();
            if (!esCorreoValido(correo)) {
                mostrarError("Correo inválido. Ej: usuario@dominio.com");
                corr.setText("");
                corr.requestFocus();
                return false;
            }

            if (BuscarUsuario(correo) != null) {
                mostrarError("El usuario ya está registrado.");
                return false;
            }

            String nombres = nomb.getText().trim();
            String apellidos = apell.getText().trim();
            if (nombres.matches(".*\\d.*") || apellidos.matches(".*\\d.*")) {
                mostrarError("El nombre o apellido no debe contener números.");
                return false;
            }

            String contrasena = cont.getText().trim();
            if (contrasena.length() < 8) {
                mostrarError("La contraseña debe tener al menos 8 caracteres.");
                cont.setText("");
                cont.requestFocus();
                return false;
            }

            Usuarios nuevo = new Usuarios(nombres, apellidos, "cliente", correo, telefono, contrasena);
            Agregarusuario(nuevo);

            nomb.setText(""); apell.setText(""); corr.setText(""); tel.setText(""); cont.setText("");
            return true;
        } catch (Exception e) {
            mostrarError("Error inesperado: " + e.getMessage());
            return false;
        }
    }

    public void Agregarusuario(Usuarios nuevo) {
        nodo<Usuarios> nuevoNodo = new nodo<>(nuevo);
        if (getVacia()) {
            cab = nuevoNodo;
        } else {
            nodo<Usuarios> p = cab;
            while (p.sig != null) {
                p = p.sig;
            }
            p.sig = nuevoNodo;
            nuevoNodo.ant = p;
        }
        guardarUsuariosEnArchivo("usuarios.txt");
    }

    public void cargarDatosEnCampos(TextField nombre, TextField apellidos, TextField correo, TextField telefono, PasswordField contrasena) {
        if (usuarioActual != null) {
            nombre.setText(usuarioActual.nombre);
            apellidos.setText(usuarioActual.apellidos);
            correo.setText(usuarioActual.correo);
            telefono.setText(usuarioActual.teléfono);
            contrasena.setText(usuarioActual.contrasena);
        }
    }

    public boolean editarUsuarioActual(TextField nombre, TextField apellidos, TextField correo, TextField telefono, PasswordField contrasena) {
        if (usuarioActual == null) {
            mostrarError("No hay usuario autenticado.");
            return false;
        }

        String nuevoNombre = nombre.getText().trim();
        String nuevoApellido = apellidos.getText().trim();
        String nuevoCorreo = correo.getText().trim();
        String nuevoTelefono = telefono.getText().trim();
        String nuevaContrasena = contrasena.getText().trim();

        if (!nuevoNombre.isEmpty() && nuevoNombre.matches(".*\\d.*")) {
            mostrarError("El nombre no debe contener números.");
            return false;
        }

        if (!nuevoApellido.isEmpty() && nuevoApellido.matches(".*\\d.*")) {
            mostrarError("El apellido no debe contener números.");
            return false;
        }

        if (!nuevoCorreo.isEmpty() && !esCorreoValido(nuevoCorreo)) {
            mostrarError("Correo inválido.");
            return false;
        }

        if (!nuevoTelefono.isEmpty() && !nuevoTelefono.matches("\\d+")) {
            mostrarError("El teléfono debe contener solo números.");
            return false;
        }

        if (!nuevaContrasena.isEmpty() && nuevaContrasena.length() < 8) {
            mostrarError("La contraseña debe tener al menos 8 caracteres.");
            return false;
        }

        if (!nuevoNombre.isEmpty()) usuarioActual.nombre = nuevoNombre;
        if (!nuevoApellido.isEmpty()) usuarioActual.apellidos = nuevoApellido;
        if (!nuevoCorreo.isEmpty()) usuarioActual.correo = nuevoCorreo;
        if (!nuevoTelefono.isEmpty()) usuarioActual.teléfono = nuevoTelefono;
        if (!nuevaContrasena.isEmpty()) usuarioActual.contrasena = nuevaContrasena;

        guardarUsuariosEnArchivo("usuarios.txt");

        return true;
    }

    public void guardarUsuariosEnArchivo(String nombreArchivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
            nodo<Usuarios> actual = cab;
            while (actual != null) {
                Usuarios u = actual.dato;
                String linea = String.join(";",
                    u.nombre, u.apellidos, u.tipo, u.correo, u.teléfono, u.contrasena);
                writer.write(linea);
                writer.newLine();
                actual = actual.sig;
            }
        } catch (IOException e) {
            mostrarError("Error al guardar usuarios: " + e.getMessage());
        }
    }

    public void cargarUsuariosDesdeArchivo(String nombreArchivo) {
        cab = null;
        File file = new File(nombreArchivo);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 6) {
                    Usuarios u = new Usuarios(partes[0], partes[1], partes[2], partes[3], partes[4], partes[5]);
                    AgregarusuarioSinGuardar(u);
                }
            }
        } catch (IOException e) {
            System.out.println("Error al cargar usuarios: " + e.getMessage());
        }
    }

    private void AgregarusuarioSinGuardar(Usuarios nuevo) {
        nodo<Usuarios> nuevoNodo = new nodo<>(nuevo);
        if (getVacia()) {
            cab = nuevoNodo;
        } else {
            nodo<Usuarios> p = cab;
            while (p.sig != null) {
                p = p.sig;
            }
            p.sig = nuevoNodo;
            nuevoNodo.ant = p;
        }
    }

    private boolean esCorreoValido(String correo) {
        String regex = "^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$";
        return Pattern.matches(regex, correo);
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
}