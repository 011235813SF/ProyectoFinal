/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ControlaDatosC {

    @FXML
    private javafx.scene.control.TextField txtNombre;
    @FXML
    private javafx.scene.control.TextField txtApellido;
    @FXML
    private javafx.scene.control.TextField txtCorreo;
    @FXML
    private javafx.scene.control.TextField txtTelefono;
    @FXML
    private javafx.scene.control.PasswordField txtContrasena;

    @FXML
    public void initialize() {
        Controlausuarios control = Controlausuarios.getInstancia();
        control.cargarDatosEnCampos(txtNombre, txtApellido, txtCorreo, txtTelefono, txtContrasena);
    }

    @FXML
    private void guardarCambios(ActionEvent event) {
        Controlausuarios control = Controlausuarios.getInstancia();
        boolean exito = control.editarUsuarioActual(txtNombre, txtApellido, txtCorreo, txtTelefono, txtContrasena);

        if (exito) {
            mostrarConfirmacion("Datos actualizados correctamente.");
        }
    }

    private void mostrarConfirmacion(String mensaje) {
        javafx.scene.control.Alert alerta = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alerta.setTitle("Confirmación");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    @FXML
    private void irAtrasDatosC(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    @FXML
    private void irACompras(ActionEvent event) {
        cambiarEscena(event, "/fxml/Compras.fxml");
    }

    @FXML
    private void irAPerfil(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    @FXML
    private void irAFavoritos(ActionEvent event) {
        cambiarEscena(event, "/fxml/ListaDeseos.fxml");
    }

    @FXML
    private void IrACarrito(ActionEvent event) {
        cambiarEscena(event, "/fxml/Carrito.fxml");
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
