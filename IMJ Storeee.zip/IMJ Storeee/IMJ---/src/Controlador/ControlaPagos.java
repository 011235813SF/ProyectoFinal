/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import java.io.*;
import java.util.Optional;
import javafx.event.ActionEvent;
import Modelos.Pedido;
import Modelos.nodo;

public class ControlaPagos {

    @FXML private RadioButton rbEfectivo;
    @FXML private RadioButton rbTarjeta;
    @FXML private TextField txtNumTarjeta;
    @FXML private TextField txtNomTitular;
    @FXML private DatePicker txtFechaVenc;
    @FXML private Label lblResumen;
    @FXML private Label lblSubtotal;
    @FXML private Label lblTotal;
    @FXML private Button btnFinalizar;
    @FXML private Label lblEnvio;


    private ToggleGroup grupoTipo = new ToggleGroup();

    @FXML
    public void initialize() {
        rbEfectivo.setToggleGroup(grupoTipo);
        rbTarjeta.setToggleGroup(grupoTipo);
        rbEfectivo.setSelected(true);
        actualizarCamposTarjeta(false);

        grupoTipo.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
            actualizarCamposTarjeta(rbTarjeta.isSelected());
        });
    }

    private void actualizarCamposTarjeta(boolean habilitar) {
        txtNumTarjeta.setDisable(!habilitar);
        txtNomTitular.setDisable(!habilitar);
        txtFechaVenc.setDisable(!habilitar);
    }

    @FXML
    private void finalizarPago(ActionEvent event) {
        String tipoPago = rbEfectivo.isSelected() ? "Efectivo" : "Tarjeta";
        String numeroTarjeta = rbTarjeta.isSelected() ? txtNumTarjeta.getText().trim() : "";
        String nombreTitular = rbTarjeta.isSelected() ? txtNomTitular.getText().trim() : "";
        String fecha = rbTarjeta.isSelected() && txtFechaVenc.getValue() != null
                       ? txtFechaVenc.getValue().toString() : "";

        String resumen = lblResumen.getText();
        double subtotal = Double.parseDouble(lblSubtotal.getText().replace("$", ""));
        double envio = 0.0; // si lo necesitas, agrega un lblEnvio y vincúlalo también
        double total = Double.parseDouble(lblTotal.getText().replace("$", ""));

        Pedido nuevo = new Pedido("direccion dummy", tipoPago, numeroTarjeta, nombreTitular, fecha, resumen, subtotal, envio, total);
        mostrarConfirmacionYProcesar(nuevo, () -> volverAlCarrito(event));
    }

    @FXML
    private void volverAlCarrito(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/Carrito.fxml"));
            Stage stage = (Stage) btnFinalizar.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private nodo<Pedido> cab;
    private static ControlaPagos instancia;

    public static ControlaPagos getInstancia() {
        if (instancia == null) instancia = new ControlaPagos();
        return instancia;
    }

    public void mostrarConfirmacionYProcesar(Pedido pago, Runnable volverACarrito) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmar pedido");
        alert.setHeaderText("¿Deseas confirmar este pedido?");
        alert.setContentText("Esta acción no se puede deshacer.");

        Optional<ButtonType> resultado = alert.showAndWait();
        if (resultado.isPresent() && resultado.get() == ButtonType.OK) {
            registrarPago(pago);
            mostrarMensaje("Pedido registrado correctamente.");
            irHistorial();
        } else {
            mostrarMensaje("Pedido cancelado.");
            volverACarrito.run();
        }
    }

    private void mostrarMensaje(String texto) {
        Alert alerta = new Alert(AlertType.INFORMATION);
        alerta.setTitle("Información");
        alerta.setContentText(texto);
        alerta.showAndWait();
    }

    private void registrarPago(Pedido nuevoPago) {
        nodo<Pedido> nuevo = new nodo<>(nuevoPago);
        if (cab == null) {
            cab = nuevo;
        } else {
            nodo<Pedido> temp = cab;
            while (temp.sig != null) temp = temp.sig;
            temp.sig = nuevo;
            nuevo.ant = temp;
        }
        guardarPagosEnArchivo();
    }

    private void guardarPagosEnArchivo() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("historial.txt"))) {
            nodo<Pedido> p = cab;
            while (p != null) {
                Pedido pago = p.dato;
                writer.write(pago.toString()); // asegúrate que Pedido tenga toString() bien definido
                writer.newLine();
                p = p.sig;
            }
        } catch (IOException e) {
            System.out.println("Error al guardar: " + e.getMessage());
        }
    }

    private void irHistorial() {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/fxml/Compras.fxml"));
            Stage stage = (Stage) btnFinalizar.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


