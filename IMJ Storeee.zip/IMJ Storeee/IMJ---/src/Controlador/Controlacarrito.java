/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Controlacarrito implements Initializable {

    private static Controlacarrito instancia;

    public static Controlacarrito getInstancia() {
        if (instancia == null) {
            instancia = new Controlacarrito();
        }
        return instancia;
    }

public static nodo<Carrito> cab = null;

    private Usuarios usuarioActual;

    public void setUsuarioActual(Usuarios usuario) {
        this.usuarioActual = usuario;
        cab = null;
        if (usuario != null) {
            cargarCarritoDesdeArchivo(getArchivoCarritoActual());
        }
    }

    public boolean getVacia() {
        return cab == null;
    }

 public void agregarCarrito(Carrito nuevo) {
    if (cab == null) {
        cab = new nodo<>(nuevo);
        cab.sig = cab;
        cab.ant = cab;
    } else {
        nodo<Carrito> actual = cab;
        do {
            if (actual.dato.producto.nombreprod.equalsIgnoreCase(nuevo.producto.nombreprod)) {
                mostrarAlerta("Información", "Este producto ya está en el carrito.");
                return; // ⛔ Ya existe, salimos sin agregar
            }
            actual = actual.sig;
        } while (actual != cab);

        // Si no lo encontró, lo agrega como nuevo
        nodo<Carrito> nuevoNodo = new nodo<>(nuevo);
        nodo<Carrito> ultimo = cab.ant;

        nuevoNodo.sig = cab;
        nuevoNodo.ant = ultimo;
        cab.ant = nuevoNodo;
        ultimo.sig = nuevoNodo;
    }

    guardarCarritoEnArchivo(getArchivoCarritoActual()); // solo si se agregó
    renderizarCarrito();
}

 private void mostrarAlerta(String titulo, String mensaje) {
    Alert alerta = new Alert(Alert.AlertType.INFORMATION);
    alerta.setTitle(titulo);
    alerta.setHeaderText(null);
    alerta.setContentText(mensaje);
    alerta.showAndWait();
}


    public void agregarCarritoSinGuardar(Carrito nuevo) {
        nodo<Carrito> nuevoNodo = new nodo<>(nuevo);
        if (getVacia()) {
            cab = nuevoNodo;
            cab.sig = cab;
            cab.ant = cab;
        } else {
            nodo<Carrito> ultimo = cab.ant;
            ultimo.sig = nuevoNodo;
            nuevoNodo.ant = ultimo;
            nuevoNodo.sig = cab;
            cab.ant = nuevoNodo;
        }
    }

    public nodo<Carrito> buscarProducto(String nombre) {
        if (getVacia()) return null;
        nodo<Carrito> p = cab;
        do {
            if (p.dato.producto.nombreprod.equalsIgnoreCase(nombre)) {
                return p;
            }
            p = p.sig;
        } while (p != cab);
        return null;
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    @FXML private VBox contenedorProductos;
    @FXML private ImageView logoImageView;
    @FXML private Label lblSubtotal;
    @FXML private Label lblTotal;

@Override
public void initialize(URL location, ResourceBundle resources) {
    URL logoUrl = getClass().getResource("/images/Logo.png");
    if (logoUrl != null && logoImageView != null) {
        logoImageView.setImage(new Image(logoUrl.toExternalForm()));
    }

    // Validar que el usuario actual no sea null
    if (Controlausuarios.getInstancia().getUsuarioActual() != null) {
        Controlacarrito.getInstancia().setUsuarioActual(Controlausuarios.getInstancia().getUsuarioActual());
    }

    renderizarCarrito();
}


    public void renderizarCarrito() {
        if (contenedorProductos == null) return;
        contenedorProductos.getChildren().clear();

        if (getVacia()) {
            Label vacio = new Label("El carrito está vacío.");
            vacio.setStyle("-fx-font-size: 16px; -fx-text-fill: gray;");
            VBox centrado = new VBox(vacio);
            centrado.setAlignment(Pos.CENTER);
            VBox.setVgrow(centrado, Priority.ALWAYS);
            contenedorProductos.getChildren().add(centrado);
            return;
        }

        nodo<Carrito> actual = cab;
        do {
            Carrito item = actual.dato;
            HBox tarjeta = new HBox(10);
            tarjeta.setPadding(new Insets(10));
            tarjeta.setAlignment(Pos.CENTER_LEFT);
            tarjeta.setStyle("-fx-background-color: white; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10;");

            ImageView imagen = new ImageView();
            try {
                File archivo = new File(item.producto.rutaimg);
                if (archivo.exists()) {
                    imagen.setImage(new Image(archivo.toURI().toString()));
                } else {
                    imagen.setImage(new Image(getClass().getResourceAsStream("/img/placeholder.png")));
                }
            } catch (Exception e) {
                imagen.setImage(new Image(getClass().getResourceAsStream("/img/placeholder.png")));
            }

            imagen.setFitWidth(50);
            imagen.setFitHeight(50);
            imagen.setPreserveRatio(true);

            VBox contenido = new VBox(5);
            Label nombre = new Label(item.producto.nombreprod);
            nombre.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");

            Spinner<Integer> spinnerCantidad = new Spinner<>(1, 99, item.cant);
            spinnerCantidad.setEditable(true);
            HBox cantidadBox = new HBox(5, new Label("Cantidad:"), spinnerCantidad);
            cantidadBox.setAlignment(Pos.CENTER_LEFT);

            // Precio unitario
Label lblPrecioUnitario = new Label(String.format("Precio: $ %,.2f", (double) item.producto.precio));
lblPrecioUnitario.setStyle("-fx-text-fill: #444; -fx-font-size: 13px;");

// Subtotal
Label lblSubtotal = new Label(String.format("Subtotal: $ %,.2f", (double) item.getSubtotal()));
lblSubtotal.setStyle("-fx-text-fill: #008080; -fx-font-weight: bold;");

// Actualizar cuando cambie la cantidad
spinnerCantidad.valueProperty().addListener((obs, oldVal, newVal) -> {
    item.cant = newVal;
    lblSubtotal.setText(String.format("Subtotal: $ %,.2f", item.getSubtotal()));
    guardarCarritoEnArchivo(getArchivoCarritoActual());
    actualizarTotales();
});


       contenido.getChildren().addAll(nombre, lblPrecioUnitario, cantidadBox, lblSubtotal);


            Button btnEliminar = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/images/Eliminar.png"))));
            btnEliminar.setStyle("-fx-background-color: transparent;");
            ((ImageView) btnEliminar.getGraphic()).setFitWidth(20);
            ((ImageView) btnEliminar.getGraphic()).setFitHeight(20);
            btnEliminar.setOnAction(e -> {
                eliminar(item.producto.nombreprod);
                renderizarCarrito();
                guardarCarritoEnArchivo(getArchivoCarritoActual());
            });

            HBox.setHgrow(contenido, Priority.ALWAYS);
            tarjeta.getChildren().addAll(imagen, contenido, btnEliminar);
            contenedorProductos.getChildren().add(tarjeta);

            actual = actual.sig;
        } while (actual != cab);

        actualizarTotales();
    }

    public void guardarCarritoEnArchivo(String archivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo))) {
            nodo<Carrito> p = cab;
            if (p != null) {
                do {
                    Carrito c = p.dato;
                    Productoc prod = c.producto;
                    String linea = String.join(";", prod.nombreprod, prod.descripcion, prod.rutaimg,
                            String.valueOf(prod.precio), String.valueOf(c.cant));
                    writer.write(linea);
                    writer.newLine();
                    p = p.sig;
                } while (p != cab);
            }
        } catch (IOException e) {
            mostrarError("Error al guardar el carrito: " + e.getMessage());
        }
    }

    public void cargarCarritoDesdeArchivo(String archivo) {
        cab = null;
        File file = new File(archivo);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 5) {
                    String nombre = partes[0];
                    String descripcion = partes[1];
                    String rutaImg = partes[2];
                    int precio = Integer.parseInt(partes[3]);
                    int cantidad = Integer.parseInt(partes[4]);

                    Productoc producto = new Productoc(nombre, descripcion, rutaImg, cantidad, precio);
                    Carrito item = new Carrito(producto, cantidad);
                    agregarCarritoSinGuardar(item);
                }
            }
        } catch (IOException e) {
            mostrarError("Error al cargar el carrito: " + e.getMessage());
        }
    }

    public void vaciarCarrito() {
        cab = null;
        guardarCarritoEnArchivo(getArchivoCarritoActual());
    }

    public boolean eliminar(String nombreprod) {
        if (getVacia()) return false;
        nodo<Carrito> actual = cab;
        do {
            if (actual.dato.producto.nombreprod.equalsIgnoreCase(nombreprod)) {
                if (actual == cab && cab.sig == cab) {
                    cab = null;
                } else {
                    actual.ant.sig = actual.sig;
                    actual.sig.ant = actual.ant;
                    if (actual == cab) cab = actual.sig;
                }
                guardarCarritoEnArchivo(getArchivoCarritoActual());
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);
        return false;
    }

    public int calcularTotal() {
        int total = 0;
        nodo<Carrito> p = cab;
        if (p != null) {
            do {
                total += p.dato.producto.precio * p.dato.cant;
                p = p.sig;
            } while (p != cab);
        }
        return total;
    }

    private void actualizarTotales() {
        double total = 0;
        nodo<Carrito> actual = cab;
        if (actual != null) {
            do {
                total += actual.dato.getSubtotal();
                actual = actual.sig;
            } while (actual != cab);
        }
        lblSubtotal.setText(String.format("$ %,.2f", total));
        lblTotal.setText(String.format("$ %,.2f", total));
    }

    public String getArchivoCarritoActual() {
        Usuarios u = Controlausuarios.getInstancia().getUsuarioActual();
        if (u != null) {
            return u.correo + "_carrito.txt";
        }
        return "carrito_default.txt";
    }

    @FXML
    private void IrAtrasCarrito(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoC.fxml");
    }
    @FXML
    private Button Pagos;
      @FXML
    private void IrADireccCompra(ActionEvent event) {
        cambiarEscena(event, "/fxml/Ndirección.fxml");
    }

    @FXML
    private void IrACatalogo(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoC.fxml");
    }

    @FXML
    private void IrAPerfil(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}