/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Modelos.*;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 *
 * @author PC
 */
public class ControlaPerfilCliente {
    @FXML
private Label lblNombreCliente;
    
    @FXML
public void initialize() {
    Usuarios usuarioActual = Controlausuarios.getInstancia().getUsuarioActual();
    if (usuarioActual != null) {
        lblNombreCliente.setText("👤 " + usuarioActual.nombre + " " + usuarioActual.apellidos);
    }
}


        @FXML
    private void cerrarSesion(ActionEvent event) {
        cambiarEscena(event, "/fxml/Loguin.fxml");  }


    
        @FXML
    private void irCatalogo(ActionEvent event) {
    cambiarEscena(event, "/fxml/CatalogoC.fxml");
}
 @FXML
private void irADireccion(ActionEvent event) {
    // Establecer el correo del usuario actual antes de cambiar de escena
    Controladirecc.getInstancia().setCorreoUsuario(Controlausuarios.getInstancia().getUsuarioActual().correo);

    cambiarEscena(event, "/fxml/Direcciones.fxml");
}


    
        @FXML
    private void irACompras(ActionEvent event) {
    cambiarEscena(event, "/fxml/Compras.fxml");
}
    
        @FXML
    private void irDatosC(ActionEvent event) {
    cambiarEscena(event, "/fxml/DatosCuenta.fxml");
}
    
        @FXML
    private void irACarrito(ActionEvent event) {
    cambiarEscena(event, "/fxml/Carrito.fxml");
}
    
        @FXML
    private void irAFavoritos(ActionEvent event) {
    cambiarEscena(event, "/fxml/ListaDeseos.fxml");
}

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
}
