/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Controlador;

import Modelos.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.text.NumberFormat;
import java.util.*;

public class Controlafav implements Initializable {
    private static Controlafav dataInstance;

    public static Controlafav getInstancia() {
        if (dataInstance == null) {
            dataInstance = new Controlafav();
        }
        return dataInstance;
    }

    public static nodo<Productoc> cab=null;
    private Usuarios usuarioActual;

    @FXML private ImageView logoImageView;
    @FXML private VBox contenedorFavoritos;
    @FXML private ScrollPane scrollFavoritos;

    public boolean getVacia() {
        return this.cab == null;
    }

    public void setUsuarioActual(Usuarios usuarioActual) {
        this.usuarioActual = usuarioActual;
    }

    private String getNombreArchivoFavoritos() {
        if (usuarioActual != null && usuarioActual.correo != null) {
            return "favoritos_" + usuarioActual.correo.replace("@", "_").replace(".", "_") + ".txt";
        }
        return "favoritos_sin_usuario.txt";
    }

    public void agregarFavorito(Productoc producto) {
        if (yaExiste(producto.nombreprod)) {
            mostrarAlerta("Información", "Este producto ya está en la lista de favoritos.");
            return;
        }

        nodo<Productoc> nuevo = new nodo<>(producto);

        if (getVacia()) {
            cab = nuevo;
            cab.sig = cab;
            cab.ant = cab;
        } else {
            nodo<Productoc> ultimo = cab.ant;
            nuevo.sig = cab;
            nuevo.ant = ultimo;
            cab.ant = nuevo;
            ultimo.sig = nuevo;
        }

        mostrarAlerta("Éxito", "Producto agregado a favoritos.");
        guardarFavoritos();
    }

    public boolean yaExiste(String nombreprod) {
        if (getVacia()) return false;

        nodo<Productoc> actual = cab;
        do {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombreprod)) {
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public boolean eliminarFavorito(String nombreprod) {
        if (getVacia()) return false;

        nodo<Productoc> actual = cab;
        boolean eliminado = false;
        do {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombreprod)) {
                if (actual == cab && cab.sig == cab) {
                    cab = null;
                } else {
                    actual.ant.sig = actual.sig;
                    actual.sig.ant = actual.ant;
                    if (actual == cab) {
                        cab = actual.sig;
                    }
                }
                eliminado = true;
                break;
            }
            actual = actual.sig;
        } while (actual != cab);

        if (eliminado) {
            mostrarAlerta("Éxito", "Producto eliminado de favoritos.");
            guardarFavoritos();
        } else {
            mostrarAlerta("Error", "No se pudo encontrar el producto en favoritos.");
        }
        return eliminado;
    }

    public void vaciarFavoritos() {
        cab = null;
        guardarFavoritos();
    }

    private void guardarFavoritos() {
        String archivo = getNombreArchivoFavoritos();
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(archivo))) {
            if (!getVacia()) {
                nodo<Productoc> actual = cab;
                do {
                    writer.write(actual.dato.toCsvString());
                    writer.newLine();
                    actual = actual.sig;
                } while (actual != cab);
            }
        } catch (IOException e) {
            System.err.println("Error al guardar favoritos: " + e.getMessage());
        }
    }

    public void cargarFavoritos() {
        cab = null;
        String archivo = getNombreArchivoFavoritos();
        File file = new File(archivo);
        if (!file.exists()) return;

        try {
            List<String> lineas = Files.readAllLines(Paths.get(archivo));
            for (String linea : lineas) {
                Productoc prod = Productoc.fromCsvString(linea);
                if (prod != null) {
                    nodo<Productoc> nuevo = new nodo<>(prod);
                    if (cab == null) {
                        cab = nuevo;
                        cab.sig = cab;
                        cab.ant = cab;
                    } else {
                        nodo<Productoc> ultimo = cab.ant;
                        nuevo.sig = cab;
                        nuevo.ant = ultimo;
                        cab.ant = nuevo;
                        ultimo.sig = nuevo;
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error al cargar favoritos: " + e.getMessage());
        }
    }

    public void renderizarFavoritos() {
        if (contenedorFavoritos == null) return;
        contenedorFavoritos.getChildren().clear();

        if (getVacia()) {
            Label vacio = new Label("No tienes productos en favoritos.");
            vacio.setStyle("-fx-font-size: 16px; -fx-text-fill: gray;");
            VBox box = new VBox(vacio);
            box.setAlignment(Pos.CENTER);
            VBox.setVgrow(box, Priority.ALWAYS);
            contenedorFavoritos.getChildren().add(box);
            return;
        }

        nodo<Productoc> actual = cab;
        do {
            Productoc prod = actual.dato;

            HBox tarjeta = new HBox(10);
            tarjeta.setPadding(new Insets(10));
            tarjeta.setAlignment(Pos.CENTER_LEFT);
            tarjeta.setStyle("-fx-background-color: white; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10;");

            ImageView imagen = new ImageView();
            if (prod.rutaimg != null && !prod.rutaimg.isEmpty()) {
                File archivoImagen = new File(prod.rutaimg);
                if (archivoImagen.exists()) {
                    imagen.setImage(new Image(archivoImagen.toURI().toString()));
                }
            }
            imagen.setFitWidth(50);
            imagen.setFitHeight(50);
            imagen.setPreserveRatio(true);

            VBox contenido = new VBox(5);
            Label nombre = new Label(prod.nombreprod);
            nombre.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");

            Spinner<Integer> spinnerCantidad = new Spinner<>(1, 99, 1);
            spinnerCantidad.setEditable(true);

            HBox cantidadBox = new HBox(5, new Label("Cantidad: "), spinnerCantidad);
            cantidadBox.setAlignment(Pos.CENTER_LEFT);

            Label precio = new Label(NumberFormat.getCurrencyInstance(new Locale("es", "CO")).format(prod.precio));
            precio.setStyle("-fx-font-weight: bold; -fx-text-fill: #008080;");

            contenido.getChildren().addAll(nombre, precio, cantidadBox);

            Button btnAgregarCarrito = new Button("Agregar al carrito");
            btnAgregarCarrito.setStyle("-fx-background-color: #00796B; -fx-text-fill: white;");
            btnAgregarCarrito.setOnAction(e -> {
                Carrito nuevo = new Carrito(prod, spinnerCantidad.getValue());
                Controlacarrito.getInstancia().agregarCarrito(nuevo);
                mostrarAlerta("Éxito", "Producto añadido al carrito.");
            });

            Button btnEliminar = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/images/Eliminar.png"))));
            btnEliminar.setStyle("-fx-background-color: transparent;");
            ((ImageView) btnEliminar.getGraphic()).setFitWidth(20);
            ((ImageView) btnEliminar.getGraphic()).setFitHeight(20);
            btnEliminar.setOnAction(e -> {
                eliminarFavorito(prod.nombreprod);
                renderizarFavoritos();
            });

            VBox botones = new VBox(5, btnEliminar, btnAgregarCarrito);
            botones.setAlignment(Pos.CENTER_RIGHT);

            HBox.setHgrow(contenido, Priority.ALWAYS);
            tarjeta.getChildren().addAll(imagen, contenido, botones);
            VBox.setMargin(tarjeta, new Insets(5, 0, 5, 0));
            contenedorFavoritos.getChildren().add(tarjeta);

            actual = actual.sig;
        } while (actual != cab);
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        URL logoUrl = getClass().getResource("/images/Logo.png");
        if (logoUrl != null && logoImageView != null) {
            logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        }
        renderizarFavoritos();
    }

    @FXML private void irAtrasFav(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoC.fxml");
    }

    @FXML private void irACarritoFav(ActionEvent event) {
        cambiarEscena(event, "/fxml/Carrito.fxml");
    }

    @FXML private void irAPerfilCli(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    @FXML
    private void irAMisCompras(ActionEvent event) {
        cambiarEscena(event, "/fxml/Compras.fxml");
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) return;
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.out.println("Error al cargar FXML: " + rutaFXML);
            e.printStackTrace();
        }
    }
}
