package Controlador;


import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.stage.*;
import java.io.*;
import java.net.URL;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.scene.*;
import javafx.fxml.Initializable;


public class ControlaAgregar implements Initializable {

    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtDescripcion;
    @FXML
    private TextField txtPrecio;
    @FXML
    private TextField txtCantidad;
    @FXML
    private Button btnCargarImagen;
    @FXML
    private ImageView imageView;
    @FXML
    private Button btnAgregar;
    @FXML
    private Button Atras;
    @FXML
    private Button Catalog;

    @FXML
    private ImageView logoImageView;

    private File imagenSeleccionada;

    @FXML
    void seleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar imagen del producto");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Imágenes", "*.png", "*.jpg", "*.jpeg")
        );
        imagenSeleccionada = fileChooser.showOpenDialog(new Stage());
        if (imagenSeleccionada != null) {
            Image image = new Image(imagenSeleccionada.toURI().toString());
            imageView.setImage(image);
        }
    }

    @FXML

    void agregarProducto(ActionEvent event) {
        boolean agregado = Controlaprodc.getInstancia().AddProducto(
                txtNombre, txtDescripcion, txtCantidad, txtPrecio, imagenSeleccionada
        );

        if (agregado) {
            mostrarAlerta("Éxito", "Producto agregado correctamente.");
            limpiarCampos();
        }
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void limpiarCampos() {
        txtNombre.clear();
        txtDescripcion.clear();
        txtPrecio.clear();
        txtCantidad.clear();
        imageView.setImage(null);
        imagenSeleccionada = null;
    }

    @FXML
    void volverAtras(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilAdm.fxml");
    }

    @FXML
    private void irCatalogo(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoAdm.fxml");
    }
    
    @FXML
    private void irAPerfil(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilAdm.fxml");
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) {
                System.out.println("No se encontró el archivo FXML: " + rutaFXML);
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.out.println("Error al cargar FXML: " + rutaFXML);
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        txtPrecio.focusedProperty().addListener((obs, oldVal, newVal) -> {
            if (!newVal) {
                String texto = txtPrecio.getText().replace(".", "");
                if (!texto.isEmpty()) {
                    try {
                        int valor = Integer.parseInt(texto);
                        NumberFormat formato = NumberFormat.getInstance(new Locale("es", "CO"));
                        txtPrecio.setText(formato.format(valor));
                    } catch (NumberFormatException e) {
                        txtPrecio.setText("");
                    }
                }
            }
        });

        URL logoUrl = getClass().getResource("/images/Logo.png");
        if (logoUrl != null && logoImageView != null) {
            logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        }
    }

    private File asegurarDirectorioImagenes() {
        File dir = new File("imagenesProductos");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        return dir;
    }

}
