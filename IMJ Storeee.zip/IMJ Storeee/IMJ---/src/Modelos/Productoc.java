/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

/**
 *
 * @author PC
 */
public class Productoc {

    public String nombreprod, descripcion, rutaimg;
    public int cant, precio;

    public Productoc(String nombreprod, String descripcion, String rutaimg, int cant, int precio) {
        this.nombreprod = nombreprod;
        this.descripcion = descripcion;
        this.rutaimg = rutaimg;
        this.cant = cant;
        this.precio = precio;
    }

    public String toCsvString() {
        return String.join(";", nombreprod, descripcion, String.valueOf(cant), String.valueOf(precio), rutaimg);
    }

    public static Productoc fromCsvString(String linea) {
        String[] partes = linea.split(";");
        if (partes.length != 5) return null;

        try {
            String nombre = partes[0];
            String descripcion = partes[1];
            int cantidad = Integer.parseInt(partes[2]);
            int precio = Integer.parseInt(partes[3]);
            String rutaimg = partes[4];

            // Orden correcto de parámetros según tu constructor
            return new Productoc(nombre, descripcion, rutaimg, cantidad, precio);
        } catch (NumberFormatException e) {
            System.err.println("Error al convertir línea CSV: " + linea);
            return null;
        }
    }
}
