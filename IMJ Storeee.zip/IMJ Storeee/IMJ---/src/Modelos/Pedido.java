/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.time.LocalDateTime;

/**
 *
 * @author PC
 */
public class Pedido {
  public String direccionEnvio;
    public String tipoPago; // "Efectivo" o "Tarjeta"
    public String numeroTarjeta; // Solo si aplica
    public String nombreTitular;
    public String fecha;
    public String resumenArticulos; // Nombre y cantidad de productos
    public double subtotal;
    public double envio;
    public double total;


    public Pedido(String direccionEnvio, String tipoPago, String numeroTarjeta, String nombreTitular,
                String fecha, String resumenArticulos, double subtotal, double envio, double total) {
        this.direccionEnvio = direccionEnvio;
        this.tipoPago = tipoPago;
        this.numeroTarjeta = numeroTarjeta;
        this.nombreTitular = nombreTitular;
        this.fecha = fecha;
        this.resumenArticulos = resumenArticulos;
        this.subtotal = subtotal;
        this.envio = envio;
        this.total = total;
 
    }

}
