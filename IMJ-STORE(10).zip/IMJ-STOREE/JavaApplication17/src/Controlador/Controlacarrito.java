/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * @author PC
 */
public class Controlacarrito implements Initializable{

    private static Controlacarrito instancia;

    public static Controlacarrito getInstancia() {
        if (instancia == null) {
            instancia = new Controlacarrito();
        }
        return instancia;
    }

    private Controlacarrito() {
        cab = null;
    }

    public nodo<Carrito> cab;

     public boolean getVacia() {
        return cab == null ? true : false;
    }


    public void agregarCarrito(Carrito item) {
        if (!getVacia()) {
            nodo<Carrito> actual = cab;
            do {
                if (actual.dato.producto.nombreprod.trim().equalsIgnoreCase(item.producto.nombreprod.trim())) {
                    mostrarError("Error: El producto ya está en el carrito");
                    return;
                }
                actual = actual.sig;
            } while (actual != cab);
        }

        nodo<Carrito> nuevo = new nodo<>(item);

        if (getVacia()) {
            cab = nuevo;
            cab.sig = cab;
            cab.ant = cab;
        } else {
            nodo<Carrito> ultimo = cab.ant;

            nuevo.sig = cab;
            nuevo.ant = ultimo;

            cab.ant = nuevo;
            ultimo.sig = nuevo;
        }
    }
    
    public double getTotal() {
    if (getVacia()) return 0;

    double total = 0;
    nodo<Carrito> actual = cab;
    do {
        total += actual.dato.getSubtotal();
        actual = actual.sig;
    } while (actual != cab);

    return total;
}


    public boolean actualizarCantidad(String nombre, int nuevaCantidad) {
        if (getVacia()) return false;

        nodo<Carrito> actual = cab;
        do {
            if (actual.dato.producto.nombreprod.trim().equalsIgnoreCase(nombre.trim())) {
                actual.dato.cant = nuevaCantidad;
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public boolean eliminar(String nombreprod) {
        if (getVacia()) return false;

        nodo<Carrito> actual = cab;
        do {
            if (actual.dato.producto.nombreprod.trim().equalsIgnoreCase(nombreprod.trim())) {
                if (actual == cab && cab.sig == cab) {
                    cab = null;
                } else {
                    actual.ant.sig = actual.sig;
                    actual.sig.ant = actual.ant;
                    if (actual == cab) {
                        cab = actual.sig;
                    }
                }
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public int contarElementos() {
        if (getVacia()) return 0;

        int contador = 0;
        nodo<Carrito> actual = cab;
        do {
            contador++;
            actual = actual.sig;
        } while (actual != cab);

        return contador;
    }

    public void Vaciar() {
        cab = null;
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
    public void renderizarCarrito(VBox contenedor) {
    contenedor.getChildren().clear();  // Limpiar tarjetas anteriores

    if (getVacia()) return;

    nodo<Carrito> actual = cab;
    do {
        Carrito item = actual.dato;

        // Contenedor principal de la tarjeta
        HBox tarjeta = new HBox(10);
        tarjeta.setPadding(new Insets(10));
        tarjeta.setAlignment(Pos.CENTER_LEFT);
        tarjeta.setStyle("-fx-background-color: white; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10;");
        
        // Imagen del producto (placeholder)
        ImageView imagen = new ImageView(new Image(getClass().getResourceAsStream("/img/placeholder.png")));
        imagen.setFitWidth(50);
        imagen.setFitHeight(50);

        // Contenido del producto
        VBox contenido = new VBox(5);
        Label nombre = new Label(item.producto.nombreprod);
        nombre.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");
        Label cantidadLbl = new Label("Cantidad");
        Spinner<Integer> cantidad = new Spinner<>(1, 99, item.cant);
        cantidad.valueProperty().addListener((obs, oldVal, newVal) -> {
            item.cant = newVal;
            // Aquí puedes actualizar el subtotal si tienes un campo que lo muestra
        });

        HBox cantidadBox = new HBox(5, cantidadLbl, cantidad);
        cantidadBox.setAlignment(Pos.CENTER_LEFT);

        TextField subtotal = new TextField(String.format("$ %.2f", item.getSubtotal()));
        subtotal.setEditable(false);

        contenido.getChildren().addAll(nombre, cantidadBox, subtotal);

        // Botón eliminar
        Button eliminarBtn = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/img/eliminar.png"))));
        eliminarBtn.setOnAction(e -> {
            eliminar(item.producto.nombreprod);
            renderizarCarrito(contenedor); // Recarga vista
        });

        tarjeta.getChildren().addAll(imagen, contenido, eliminarBtn);
        contenedor.getChildren().add(tarjeta);

        actual = actual.sig;
    } while (actual != cab);
}

    @FXML
    private ImageView logoImageView;
    
    @FXML
    private VBox contenedorProductos;

    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        URL logoUrl = getClass().getResource("/images/Logo.png");
if (logoUrl != null && logoImageView != null) {
    logoImageView.setImage(new Image(logoUrl.toExternalForm()));
}
}
}
