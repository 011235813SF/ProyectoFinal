/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Arledys Guevara
 */

public class carritoManager {
    private static carritoManager instance;
    private final List<Productoc> carrito;

    private carritoManager() {
        carrito = new ArrayList<>();
    }

    public static carritoManager getInstance() {
        if (instance == null) {
            instance = new carritoManager();
        }
        return instance;
    }

    public void agregarProducto(Productoc producto) {
        carrito.add(producto);
    }

    public List<Productoc> obtenerProductos() {
        return new ArrayList<>(carrito);
    }

    public void limpiarCarrito() {
        carrito.clear();
    }
}
