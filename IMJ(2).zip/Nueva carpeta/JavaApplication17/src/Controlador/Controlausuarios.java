/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Modelos.*;
import javafx.scene.control.*;
   import java.util.regex.*;
/**
 *
 * @author PC
 */
public class Controlausuarios {
    
    public nodo<Usuarios> cab;
    
public void agregarUsuarioManual() {
    Usuarios nuevo = new Usuarios(
        "Isabela",         // nombre
        "Valdés",        // apellidos
        "admin",      // tipo
        "isa@gmail.com",// correo
        "1234567890",   // teléfono
        "123" // contraseña
    );
    Agregarusuario(nuevo);
}

    public Controlausuarios() {
        cab = null;
         agregarUsuarioManual();
    }

    public boolean getVacia() {
        return cab == null ? true : false;
    }

    public int getTamlista() {
        if (getVacia()) {
            return 0;
        } else {
            nodo<Usuarios> p = cab;
            int cont = 0;
            while (p != null) {
                cont++;
                p = p.sig;
            }
            return cont;
        }
    }

    public nodo<Usuarios> getUltimo() {
        if (getVacia()) {
            return null;
        } else {
            nodo<Usuarios> p = cab;
            while (p.sig != null) {
                p = p.sig;
            }
            return p;
        }
    }
 

public boolean esCorreoValido(String correo) {
    String regex = "^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$";
    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(correo);
    return matcher.matches();
}


    public nodo<Usuarios> BuscarUsuario(String corr) {
        if (getVacia()) {
            return null;
        } else {
            nodo<Usuarios> p = cab;
            while (p != null) {
                if (p.dato.correo.equals(corr)) {
                    return p;
                } else {
                    p = p.sig;
                }
            }
            return null;
        }
    }
    
    public void mostrarError(String mensaje) {
    Alert alerta = new Alert(Alert.AlertType.ERROR);
    alerta.setTitle("Error");
    alerta.setHeaderText(null);
    alerta.setContentText(mensaje);
    alerta.showAndWait();
}

    public boolean AddUsuario(TextField nomb, TextField apell, TextField corr, TextField tel, TextField cont ) {
        try {

            // Validar campos vacíos
            if (nomb.getText().trim().isEmpty() || apell.getText().trim().isEmpty()
                    || corr.getText().trim().isEmpty() || tel.getText().trim().isEmpty()
                    || cont.getText().trim().isEmpty()) {
                mostrarError("¡Error! Debe llenar todos los campos.");
                return false;
            }

            // Obtener y validar teléfono
            String telefono = tel.getText().trim();
            if (!telefono.matches("\\d+")) {
                mostrarError("Error!!! El teléfono solo debe contener números");
                tel.setText("");
                tel.requestFocus();
                return false;
            }
            String correo = corr.getText().trim();
            
            if (!esCorreoValido(correo)) {
                mostrarError("Correo inválido. Ej: usuario@dominio.com");
            }
            
            nodo<Usuarios> existente = BuscarUsuario(correo);
            if (existente != null) {
                mostrarError( "Error!!! El registro ya existe.");
                return false;
            }

            // Obtener y validar nombres y apellidos 
            String nombres = nomb.getText().trim();
            String apellidos = apell.getText().trim();
            if (nombres.matches(".*\\d.*") || apellidos.matches(".*\\d.*")) {
               mostrarError("Error!!! El nombre del paciente ni el de familiar debe contener números.");
                return false;
            }
            
            String Tipo="Cliente";

            // contraseña
            String contrasea = cont.getText().trim();
            
            Usuarios nuevo  = new Usuarios(nombres, apellidos,Tipo, correo, telefono, contrasea);
            
            Agregarusuario(nuevo);


            return true;

        } catch (Exception e) {
            mostrarError( "Ocurrió un error inesperado: " + e.getMessage());
        }
        return false;
    }
    
        public void Agregarusuario(Usuarios nuevo) {
        nodo<Usuarios> nuevoNodo = new nodo<>(nuevo);
        if (getVacia()) {
            cab = nuevoNodo;
        } else {
            nodo<Usuarios> p = cab;
            while (p.sig != null) {
                p = p.sig;
            }
            p.sig = nuevoNodo;
            nuevoNodo.ant = p;
        }
    }
}
