/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import java.io.IOException;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class ControlaLogin {

    @FXML
    private TextField txtCorreo;

    @FXML
    private PasswordField txtPassword;

    private Controlausuarios control = new Controlausuarios(); 

    @FXML
    private void iniciarSesion() {
        String correo = txtCorreo.getText().trim();
        String clave = txtPassword.getText().trim();

        nodo<Usuarios> usuario = control.BuscarUsuario(correo);

        if (usuario != null && usuario.dato.correo.equals(correo) && usuario.dato.contrasena.equals(clave)) {
            String tipo = usuario.dato.tipo;
            if (tipo.equalsIgnoreCase("admin")) {
                cambiarEscena("/fxml/CatalogoAdm.fxml");
            } else if (tipo.equalsIgnoreCase("cliente")) {
                cambiarEscena("/fxml/Catalogo.fxml");
            }
        } else {
            mostrarError("Credenciales incorrectas");
        }
    }
    
    private void cambiarEscena(String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../fxml/CatalogoAdm.fxml"));

            Parent root = loader.load();
            Stage stage = (Stage) txtCorreo.getScene().getWindow(); // Obtener ventana actual
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            mostrarError("Error al cargar la vista: " + e.getMessage());
        }
    }

    private void mostrarMensaje(String texto) {
        Alert alerta = new Alert(AlertType.INFORMATION);
        alerta.setTitle("Login");
        alerta.setHeaderText(null);
        alerta.setContentText(texto);
        alerta.showAndWait();
    }

    private void mostrarError(String texto) {
        Alert alerta = new Alert(AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(texto);
        alerta.showAndWait();
    }
    
    @FXML
private void cancelar() {
    cambiarEscena("/fxml/PagP.fxml");
}

}
