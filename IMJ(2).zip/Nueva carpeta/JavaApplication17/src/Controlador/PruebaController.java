package Controlador;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;

public class PruebaController implements Initializable {

    @FXML
    private ImageView carruselImage;

    @FXML
    private Button btnlog;

    private List<Image> imagenes;
    private int indiceActual = 0;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        imagenes = List.of(
            new Image(getClass().getResource("/images/img1.png").toExternalForm()),
            new Image(getClass().getResource("/images/img2.png").toExternalForm()),
            new Image(getClass().getResource("/images/img3.png").toExternalForm()),
            new Image(getClass().getResource("/images/img4.png").toExternalForm()),
            new Image(getClass().getResource("/images/img5.png").toExternalForm())
        );

        carruselImage.setImage(imagenes.get(0));

        Timeline timeline = new Timeline(
            new KeyFrame(Duration.seconds(5), event -> cambiarImagen())
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
    }

    private void cambiarImagen() {
        indiceActual = (indiceActual + 1) % imagenes.size();
        carruselImage.setImage(imagenes.get(indiceActual));
    }

    @FXML
    private void irLogin() {
        cambiarEscena("/fxml/Loguin.fxml");
    }

    private void cambiarEscena(String rutaFXML) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) {
                System.out.println("No se encontró el archivo FXML: " + rutaFXML);
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();
            Stage stage = (Stage) btnlog.getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            System.out.println("Error al cargar FXML: " + rutaFXML);
            e.printStackTrace();
        }
    }
}
