/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;
import Controlador.*;

/**
 *
 * @author PC
 */
public class Usuarios {

    public String nombre, apellidos, correo, teléfono, contrasena, tipo;
        public Controladirecc direcciones;

    public Usuarios(String nombre, String apellidos,String tipo, String correo, String teléfono, String contrasena) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.tipo=tipo;
        this.correo = correo;
        this.teléfono = teléfono;
        this.contrasena = contrasena;
        this.direcciones = new Controladirecc();
    }
    
       public void agregarDireccion(Direcciones d) {
        direcciones.agregarDireccion(d);
    }
}
