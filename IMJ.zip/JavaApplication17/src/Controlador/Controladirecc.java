/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;
import Modelos.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
/**
 *
 * @author PC
 */
public class Controladirecc {


    private static Controladirecc instancia;

    public static Controladirecc getInstancia() {
        if (instancia == null) {
            instancia = new Controladirecc();
        }
        return instancia;
    }

    private nodo<Direcciones> cab;

    public Controladirecc() {
        cab = null;
    }

    public boolean getVacia() {
        return cab == null;
    }

    public int getTamlista() {
        int count = 0;
        nodo<Direcciones> p = cab;
        while (p != null) {
            count++;
            p = p.sig;
        }
        return count;
    }

    public void agregarDireccion(Direcciones nueva) {
        nodo<Direcciones> nuevoNodo = new nodo<>(nueva);
        if (cab == null) {
            cab = nuevoNodo;
        } else {
            nodo<Direcciones> p = cab;
            while (p.sig != null) {
                p = p.sig;
            }
            p.sig = nuevoNodo;
            nuevoNodo.ant = p;
        }
    }

    public Direcciones getDireccion(int index) {
        nodo<Direcciones> p = cab;
        int i = 0;
        while (p != null) {
            if (i == index) return p.dato;
            i++;
            p = p.sig;
        }
        return null;
    }

    public boolean eliminarDireccion(int index) {
        if (cab == null) return false;
        nodo<Direcciones> actual = cab;
        int i = 0;
        while (actual != null && i < index) {
            actual = actual.sig;
            i++;
        }
        if (actual == null) return false;

        if (actual.ant != null) {
            actual.ant.sig = actual.sig;
        } else {
            cab = actual.sig;
        }
        if (actual.sig != null) {
            actual.sig.ant = actual.ant;
        }
        return true;
    }

    public boolean AddDireccion(TextField dirEntrega, TextField departamento, TextField municipio,
                                 TextField barrio, TextField apto, TextArea indicaciones,
                                 ToggleGroup tipoGrupo, TextField contacto, TextField telContacto) {
        try {
            if (dirEntrega.getText().trim().isEmpty() || departamento.getText().trim().isEmpty()
                    || municipio.getText().trim().isEmpty() || barrio.getText().trim().isEmpty()
                    || contacto.getText().trim().isEmpty() || telContacto.getText().trim().isEmpty()) {
                Controlausuarios.getInstancia().mostrarError("¡Error! Debe llenar todos los campos obligatorios.");
                return false;
            }

            String tipo = ((RadioButton) tipoGrupo.getSelectedToggle()).getText();
            if (tipo == null || tipo.isEmpty()) {
                Controlausuarios.getInstancia().mostrarError("Debe seleccionar el tipo de domicilio.");
                return false;
            }

            if (!telContacto.getText().trim().matches("\\d+")) {
                Controlausuarios.getInstancia().mostrarError("El teléfono de contacto solo debe contener números.");
                telContacto.requestFocus();
                return false;
            }

            Direcciones nueva = new Direcciones(
                    dirEntrega.getText().trim(),
                    departamento.getText().trim(),
                    municipio.getText().trim(),
                    barrio.getText().trim(),
                    apto.getText().trim(),
                    indicaciones.getText().trim(),
                    tipo,
                    contacto.getText().trim(),
                    telContacto.getText().trim()
            );

            agregarDireccion(nueva);

            dirEntrega.clear();
            departamento.clear();
            municipio.clear();
            barrio.clear();
            apto.clear();
            indicaciones.clear();
            contacto.clear();
            telContacto.clear();
            tipoGrupo.selectToggle(null);

            return true;

        } catch (Exception e) {
            Controlausuarios.getInstancia().mostrarError("Error al agregar dirección: " + e.getMessage());
            return false;
        }
    }

    public boolean EditarDireccion(int index, TextField dirEntrega, TextField departamento, TextField municipio,
                                   TextField barrio, TextField apto, TextArea indicaciones,
                                   ToggleGroup tipoGrupo, TextField contacto, TextField telContacto) {
        try {
            Direcciones dir = getDireccion(index);
            if (dir == null) {
                Controlausuarios.getInstancia().mostrarError("Dirección no encontrada.");
                return false;
            }

            String tipo = ((RadioButton) tipoGrupo.getSelectedToggle()).getText();
            if (!telContacto.getText().trim().matches("\\d+")) {
                Controlausuarios.getInstancia().mostrarError("El teléfono de contacto solo debe contener números.");
                telContacto.requestFocus();
                return false;
            }

            dir.direccionentrega = dirEntrega.getText().trim();
            dir.depto = departamento.getText().trim();
            dir.municp = municipio.getText().trim();
            dir.barr = barrio.getText().trim();
            dir.espcf = apto.getText().trim();
            dir.adci = indicaciones.getText().trim();
            dir.tipo = tipo;
            dir.nomb = contacto.getText().trim();
            dir.tel = telContacto.getText().trim();

            return true;

        } catch (Exception e) {
            Controlausuarios.getInstancia().mostrarError("Error al editar dirección: " + e.getMessage());
            return false;
        }
    }
    
    public HBox crearTarjetaDireccion(Direcciones dir, int index, ToggleGroup toggleGroup) {
    HBox tarjeta = new HBox(10);
    tarjeta.setPadding(new Insets(10));
    tarjeta.setStyle("-fx-background-color: white; -fx-background-radius: 10; -fx-border-radius: 10; -fx-border-color: #ccc;");
    tarjeta.setAlignment(Pos.CENTER_LEFT);

    // RadioButton de selección
    RadioButton radio = new RadioButton();
    radio.setToggleGroup(toggleGroup);
    radio.setUserData(index);

    // Ícono
    ImageView icono = new ImageView();
    Image img = new Image(getClass().getResourceAsStream(
        dir.tipo.equalsIgnoreCase("Residencial") ? "/icons/home.png" : "/icons/work.png"
    ));
    icono.setImage(img);
    icono.setFitHeight(40);
    icono.setFitWidth(40);

    // Contenedor de texto
    VBox textos = new VBox(5);
    Label lblDir = new Label("Dirección");
    lblDir.setFont(Font.font("Arial", FontWeight.BOLD, 14));
    Label lblMun = new Label(dir.municp);
    Label lblNombre = new Label(dir.nomb);
    Label lblTel = new Label(dir.tel);

    textos.getChildren().addAll(lblDir, lblMun, lblNombre, lblTel);





    tarjeta.getChildren().addAll(radio, icono, textos);
    return tarjeta;
}

   public void mostrarTodasDirecciones(VBox contenedor, Controladirecc lista) {
    contenedor.getChildren().clear();
    ToggleGroup grupo = new ToggleGroup();
    int i = 0;
    nodo<Direcciones> actual = lista.cab;
    while (actual != null) {
        contenedor.getChildren().add(crearTarjetaDireccion(actual.dato, i, grupo));
        actual = actual.sig;
        i++;
    }
}




    
}
