/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

/**
 *
 * @author PC
 */
public class Controlafav implements Initializable{

    private static Controlafav instancia;

    public static Controlafav getInstancia() {
        if (instancia == null) {
            instancia = new Controlafav();
        }
        return instancia;
    }

    public nodo<Productoc> cab;

    public boolean getVacia() {
        return cab == null ? true : false;
    }

    public void agregarFavorito(Productoc producto) {
        if (yaExiste(producto.nombreprod)) {
            mostrarError("Este producto ya está en la lista de favoritos.");
            return;
        }

        nodo<Productoc> nuevo = new nodo<>(producto);

        if (getVacia()) {
            cab = nuevo;
            cab.sig = cab;
            cab.ant = cab;
        } else {
            nodo<Productoc> ultimo = cab.ant;
            nuevo.sig = cab;
            nuevo.ant = ultimo;
            cab.ant = nuevo;
            ultimo.sig = nuevo;
        }
    }

    public boolean yaExiste(String nombreprod) {
        if (getVacia()) return false;

        nodo<Productoc> actual = cab;
        do {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombreprod)) {
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public boolean eliminarFavorito(String nombreprod) {
        if (getVacia()) return false;

        nodo<Productoc> actual = cab;
        do {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombreprod)) {
                if (actual == cab && cab.sig == cab) {
                    cab = null;
                } else {
                    actual.ant.sig = actual.sig;
                    actual.sig.ant = actual.ant;
                    if (actual == cab) {
                        cab = actual.sig;
                    }
                }
                return true;
            }
            actual = actual.sig;
        } while (actual != cab);

        return false;
    }

    public int contarFavoritos() {
        if (getVacia()) return 0;

        int contador = 0;
        nodo<Productoc> actual = cab;
        do {
            contador++;
            actual = actual.sig;
        } while (actual != cab);

        return contador;
    }

    public void vaciarFavoritos() {
        cab = null;
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }
    public void renderizarFavoritos(VBox contenedor) {
    contenedor.getChildren().clear();  // Limpiar el contenido anterior

    if (getVacia()) return;

    nodo<Productoc> actual = cab;
    do {
        Productoc prod = actual.dato;

        // Tarjeta principal
        HBox tarjeta = new HBox(10);
        tarjeta.setPadding(new Insets(10));
        tarjeta.setAlignment(Pos.CENTER_LEFT);
        tarjeta.setStyle("-fx-background-color: white; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10;");

        // Imagen del producto
        ImageView imagen = new ImageView(new Image(getClass().getResourceAsStream("/img/placeholder.png")));
        imagen.setFitWidth(50);
        imagen.setFitHeight(50);

        // Contenido
        VBox contenido = new VBox(5);
        Label nombre = new Label(prod.nombreprod);
        nombre.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");

        Spinner<Integer> spinnerCantidad = new Spinner<>(1, 99, 1);
        HBox cantidadBox = new HBox(5, new Label("Cantidad"), spinnerCantidad);
        cantidadBox.setAlignment(Pos.CENTER_LEFT);

        TextField subtotal = new TextField(String.format("$ %.2f", prod.precio));
        subtotal.setEditable(false);

        contenido.getChildren().addAll(nombre, cantidadBox, subtotal);

        // Botón agregar al carrito
        Button btnAgregarCarrito = new Button("Agregar al carrito");
        btnAgregarCarrito.setStyle("-fx-background-color: #00796B; -fx-text-fill: white;");
        btnAgregarCarrito.setOnAction(e -> {
            Carrito nuevo = new Carrito(prod, spinnerCantidad.getValue());
            Controlacarrito.getInstancia().agregarCarrito(nuevo);
        });

        // Botón eliminar
        Button btnEliminar = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/img/eliminar.png"))));
        btnEliminar.setOnAction(e -> {
            eliminarFavorito(prod.nombreprod);
            renderizarFavoritos(contenedor);  // Refresca la lista
        });

        VBox botones = new VBox(5, btnEliminar, btnAgregarCarrito);
        botones.setAlignment(Pos.CENTER_RIGHT);

        tarjeta.getChildren().addAll(imagen, contenido, botones);
        contenedor.getChildren().add(tarjeta);

        actual = actual.sig;
    } while (actual != cab);
}

    @FXML
    private ImageView logoImageView;
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
        URL logoUrl = getClass().getResource("/images/Logo.png");
if (logoUrl != null && logoImageView != null) {
    logoImageView.setImage(new Image(logoUrl.toExternalForm()));
}
}
}

