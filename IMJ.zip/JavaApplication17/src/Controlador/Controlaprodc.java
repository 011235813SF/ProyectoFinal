/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

/**
 * Clase para el manejo de productos como lista enlazada.
 */
public class Controlaprodc {
    private static Controlaprodc instancia;
    public nodo<Productoc> cab;

    public static Controlaprodc getInstancia() {
        if (instancia == null) {
            instancia = new Controlaprodc();
        }
        return instancia;
    }

    public boolean getVacia() {
        return cab == null;
    }

    public int getTamanoLista() {
        int contador = 0;
        nodo<Productoc> actual = cab;
        while (actual != null) {
            contador++;
            actual = actual.sig;
        }
        return contador;
    }

    public nodo<Productoc> getUltimo() {
        nodo<Productoc> actual = cab;
        if (actual == null) return null;
        while (actual.sig != null) {
            actual = actual.sig;
        }
        return actual;
    }

    public nodo<Productoc> BuscaProdxN(String nombre) {
        nodo<Productoc> actual = cab;
        while (actual != null) {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombre)) {
                return actual;
            }
            actual = actual.sig;
        }
        return null;
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    public boolean AddProducto(TextField nomb, TextField desc, TextField cant, TextField prec, TextField ruti) {
        try {
            if (nomb.getText().isBlank() || desc.getText().isBlank()
                    || cant.getText().isBlank() || prec.getText().isBlank()
                    || ruti.getText().isBlank()) {
                mostrarError("¡Error! Debe llenar todos los campos.");
                return false;
            }

            String nombre = nomb.getText().trim();
            String descripcion = desc.getText().trim();
            String rutaImagen = ruti.getText().trim();
            int cantidad, precio;

            try {
                cantidad = Integer.parseInt(cant.getText().trim());
                precio = Integer.parseInt(prec.getText().trim());
            } catch (NumberFormatException e) {
                mostrarError("El precio y la cantidad deben ser números enteros.");
                return false;
            }

            if (BuscaProdxN(nombre) != null) {
                mostrarError("El producto ya existe.");
                return false;
            }

            Productoc nuevo = new Productoc(nombre, descripcion, rutaImagen, cantidad, precio);
            AgregarProducto(nuevo);

            // Limpiar campos
            nomb.setText("");
            desc.setText("");
            cant.setText("");
            prec.setText("");
            ruti.setText("");

            return true;

        } catch (Exception e) {
            mostrarError("Error inesperado: " + e.getMessage());
            return false;
        }
    }

    public void AgregarProducto(Productoc u) {
        nodo<Productoc> nuevo = new nodo<>(u);
        if (cab == null) {
            cab = nuevo;
        } else {
            getUltimo().sig = nuevo;
        }
    }

    public void ordenarProductosAZ() {
        if (cab == null || cab.sig == null) return;

        for (nodo<Productoc> actual = cab; actual.sig != null; actual = actual.sig) {
            for (nodo<Productoc> siguiente = actual.sig; siguiente != null; siguiente = siguiente.sig) {
                if (actual.dato.nombreprod.compareToIgnoreCase(siguiente.dato.nombreprod) > 0) {
                    Productoc temp = actual.dato;
                    actual.dato = siguiente.dato;
                    siguiente.dato = temp;
                }
            }
        }
    }
}
