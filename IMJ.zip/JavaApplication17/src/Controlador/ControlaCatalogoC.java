/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import java.text.NumberFormat;
import java.util.Locale;

/**
 *
 * @author Camila
 */
public class ControlaCatalogoC implements Initializable {
    
    @FXML
    private ImageView logoImageView;

    @FXML
    private GridPane grid;
    
    @FXML
private Button PerfilCliente;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        actualizarCatalogo();
        
        URL logoUrl = getClass().getResource("/images/Logo.png");
if (logoUrl != null && logoImageView != null) {
    logoImageView.setImage(new Image(logoUrl.toExternalForm()));
}
    }

    public void actualizarCatalogo() {
        grid.getChildren().clear();
        List<Productoc> productos = GestorProductos.getInstance().obtenerProductos();

        int column = 0;
        int row = 0;

        for (Productoc producto : productos) {
            VBox tarjeta = crearTarjetaProducto(producto);
            grid.add(tarjeta, column++, row);
            if (column == 4) {
                column = 0;
                row++;
            }
        }
    }

private VBox crearTarjetaProducto(Productoc producto) {
    VBox tarjeta = new VBox(5);
    tarjeta.setPadding(new Insets(10));
    tarjeta.setStyle("-fx-border-color: lightgray; -fx-border-radius: 5; -fx-background-color: white;");
    tarjeta.setAlignment(Pos.CENTER);
    tarjeta.setPrefSize(200, 260); // Aumentado un poco para más espacio

    // Imagen del producto
    ImageView img = new ImageView();
    try {
        Image imagen = new Image(producto.rutaimg);
        img.setImage(imagen);
    } catch (Exception e) {
        System.out.println("No se pudo cargar la imagen: " + producto.rutaimg);
    }
    img.setFitWidth(120);
    img.setFitHeight(120);
    img.setPreserveRatio(true);

    // Nombre del producto
    Label nombre = new Label(producto.nombreprod);
    nombre.setStyle("-fx-font-weight: bold; -fx-text-fill: #000066;"); // opcional: color oscuro

    // Descripción
    Label descripcion = new Label(producto.descripcion);
    descripcion.setWrapText(true);

    // Precio
    NumberFormat formato = NumberFormat.getInstance(new Locale("es", "CO"));
String precioFormateado = formato.format(producto.precio);
Label precio = new Label("$ " + precioFormateado);

Button btnAgregar = new Button("Añadir al carrito");
btnAgregar.setStyle("""
    -fx-background-color: #008080;
    -fx-text-fill: white;
    -fx-font-size: 11px;  /* Tamaño de fuente reducido */
    -fx-background-radius: 6;
""");
btnAgregar.setPrefSize(100, 25);  // Ancho y alto más pequeños
btnAgregar.setOnAction(e -> {
    System.out.println("Producto añadido al carrito: " + producto.nombreprod);
});


    // Botón favorito con corazón
    Button btnFavorito = new Button("♡");
    btnFavorito.setStyle("""
        -fx-background-color: transparent;
        -fx-font-size: 20px;
        -fx-text-fill: #cc0000;
        -fx-cursor: hand;
    """);
    btnFavorito.setPrefSize(40, 40);
    btnFavorito.setOnAction(e -> {
        System.out.println("Producto añadido a favoritos: " + producto.nombreprod);
    });

    // Contenedor de botones
    HBox contenedorBotones = new HBox(10);
    contenedorBotones.setAlignment(Pos.CENTER);
    contenedorBotones.getChildren().addAll(btnAgregar, btnFavorito);

    // Agregar componentes a la tarjeta
    tarjeta.getChildren().addAll(img, nombre, descripcion, precio, contenedorBotones);

    return tarjeta;
}


   @FXML
     private Button PerfilClient; 

    @FXML
       void irAPerfilCliente(ActionEvent event) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/PerfilClient.fxml")); // Ajusta la ruta si es necesario
        Parent root = loader.load();
        Stage stage = (Stage) PerfilCliente.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    }

