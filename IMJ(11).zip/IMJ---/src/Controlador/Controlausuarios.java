/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import javafx.scene.control.*;
import java.util.regex.*;
import java.io.*;

/**
 *
 * @author PC
 */
public class Controlausuarios {
    private static Controlausuarios instancia;

    public static Controlausuarios getInstancia() {
        if (instancia == null) {
            instancia = new Controlausuarios();
        }
        return instancia;
    }
    public nodo<Usuarios> cab;

public void agregarUsuarioManual() {
    String correoAdmin = "isa@gmail.com";
    String correoCliente = "isav@gmail.com";

    if (BuscarUsuario(correoAdmin) == null) {
        Usuarios usuario1 = new Usuarios("Isabela", "Valdés", "admin", correoAdmin, "1234567890", "123");
        Agregarusuario(usuario1);
    }

    if (BuscarUsuario(correoCliente) == null) {
        Usuarios usuario2 = new Usuarios("Isabela", "Valdés", "cliente", correoCliente, "1234567890", "123");
        Agregarusuario(usuario2);
    }
}


    public Controlausuarios() {
        cab = null;
        cargarUsuariosDesdeArchivo("usuarios.txt");
agregarUsuarioManual();
    }

    public boolean getVacia() {
        return cab == null ? true : false;
    }

    public int getTamlista() {
        if (getVacia()) {
            return 0;
        } else {
            nodo<Usuarios> p = cab;
            int cont = 0;
            while (p != null) {
                cont++;
                p = p.sig;
            }
            return cont;
        }
    }

    public nodo<Usuarios> getUltimo() {
        if (getVacia()) {
            return null;
        } else {
            nodo<Usuarios> p = cab;
            while (p.sig != null) {
                p = p.sig;
            }
            return p;
        }
    }

    public boolean esCorreoValido(String correo) {
        String regex = "^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(correo);
        return matcher.matches();
    }

    public nodo<Usuarios> BuscarUsuario(String corr) {
        if (getVacia()) {
            return null;
        } else {
            nodo<Usuarios> p = cab;
            while (p != null) {
                if (p.dato.correo.equals(corr)) {
                    return p;
                } else {
                    p = p.sig;
                }
            }
            return null;
        }
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    public boolean AddUsuario(TextField nomb, TextField apell, TextField corr, TextField tel, TextField cont) {
        try {

            // Validar campos vacíos
            if (nomb.getText().trim().isEmpty() || apell.getText().trim().isEmpty()
                    || corr.getText().trim().isEmpty() || tel.getText().trim().isEmpty()
                    || cont.getText().trim().isEmpty()) {
                mostrarError("¡Error! Debe llenar todos los campos.");
                return false;
            }

            // Obtener y validar teléfono
            String telefono = tel.getText().trim();
            if (!telefono.matches("\\d+")) {
                mostrarError("Error!!! El teléfono solo debe contener números");
                tel.setText("");
                tel.requestFocus();
                return false;
            }
            String correo = corr.getText().trim();

            if (!esCorreoValido(correo)) {
                mostrarError("Correo inválido. Ej: usuario@dominio.com");
                corr.setText("");
                corr.requestFocus();
                return false;
            }

            nodo<Usuarios> existente = BuscarUsuario(correo);
            if (existente != null) {
                mostrarError("Error!!! El registro ya existe.");
                return false;
            }

            // Obtener y validar nombres y apellidos 
            String nombres = nomb.getText().trim();
            String apellidos = apell.getText().trim();
            if (nombres.matches(".\\d.") || apellidos.matches(".\\d.")) {
                mostrarError("Error!!! Ni el nombre ni apellido debe contener números.");
                return false;
            }

            String Tipo = "cliente";

            // contraseña
            String contrasea = cont.getText().trim();

            if (contrasea.length() < 8) {
                mostrarError("La contraseña debe tener al menos 8 caracteres.");
                cont.setText("");
                cont.requestFocus();
                return false;
}


            Usuarios nuevo = new Usuarios(nombres, apellidos, Tipo, correo, telefono, contrasea);

            Agregarusuario(nuevo);
            
            nomb.setText("");
            apell.setText("");
            corr.setText("");
            tel.setText("");
            cont.setText("");
           
            return true;
            

        } catch (Exception e) {
            mostrarError("Ocurrió un error inesperado: " + e.getMessage());
        }
        return false;
    }
       private void mostrarMensaje(String texto) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setHeaderText(null);
        alerta.setContentText(texto);
        alerta.showAndWait();
    }
    
        public boolean UpdtUsuario(String original, TextField nomb, TextField apell, TextField corr, TextField tel, TextField cont) {
        try {

            // Validar campos vacíos
            if (nomb.getText().trim().isEmpty() || apell.getText().trim().isEmpty()
                    || corr.getText().trim().isEmpty() || tel.getText().trim().isEmpty()
                    || cont.getText().trim().isEmpty()) {
                mostrarError("¡Error! Debe llenar todos los campos.");
                return false;
            }

            // Obtener y validar teléfono
            String telefono = tel.getText().trim();
            if (!telefono.matches("\\d+")) {
                mostrarError("Error!!! El teléfono solo debe contener números");
                tel.setText("");
                tel.requestFocus();
                return false;
            }
            String nuevocorreo = corr.getText().trim();

            if (!esCorreoValido(nuevocorreo)) {
                mostrarError("Correo inválido. Ej: usuario@dominio.com");
                corr.setText("");
                corr.requestFocus();
                return false;
            }
            
 // Si el registro ha cambiado, verificar que no exista ya
            if (!nuevocorreo.equals(original)) {
                nodo<Usuarios> existente = BuscarUsuario(nuevocorreo);
                if (existente != null) {
                    mostrarError( "Error!!! El nuevo registro ya existe.");
                    return false;
                }
            }


            // Obtener y validar nombres y apellidos 
            String nombres = nomb.getText().trim();
            String apellidos = apell.getText().trim();
            if (nombres.matches(".\\d.") || apellidos.matches(".\\d.")) {
                mostrarError("Error!!! Ni el nombre ni apellido debe contener números.");
                return false;
            }

            String Tipo = "cliente";

            // contraseña
            String contrasea = cont.getText().trim();

            if (contrasea.length() < 8) {
                mostrarError("La contraseña debe tener al menos 8 caracteres.");
                cont.setText("");
                cont.requestFocus();
                return false;
}

 // Buscar el nodo a actualizar
            nodo<Usuarios> nodoActualizar = BuscarUsuario(original);
            if (nodoActualizar == null) {
                mostrarError("Error!!! No se encontró el registro original para actualizar.");
                return false;
            }
            
            // Actualizar los datos del paciente
            nodoActualizar.dato.correo = nuevocorreo;
            nodoActualizar.dato.nombre = nombres;
            nodoActualizar.dato.apellidos = apellidos;
            nodoActualizar.dato.teléfono = telefono;
            nodoActualizar.dato.contrasena = contrasea;

            mostrarMensaje("Paciente actualizado correctamente.");
            return true;            

        } catch (Exception e) {
            mostrarError("Ocurrió un error inesperado: " + e.getMessage());
        }
        return false;
    }

    public void Agregarusuario(Usuarios nuevo) {
    nodo<Usuarios> nuevoNodo = new nodo<>(nuevo);
    if (getVacia()) {
        cab = nuevoNodo;
    } else {
        nodo<Usuarios> p = cab;
        while (p.sig != null) {
            p = p.sig;
        }
        p.sig = nuevoNodo;
        nuevoNodo.ant = p;
    }
    guardarUsuariosEnArchivo("usuarios.txt");
}
    
    public void guardarUsuariosEnArchivo(String nombreArchivo) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
        nodo<Usuarios> actual = cab;
        while (actual != null) {
            Usuarios u = actual.dato;
            String linea = String.join(";", 
                u.nombre, 
                u.apellidos, 
                u.tipo, 
                u.correo, 
                u.teléfono, 
                u.contrasena
            );
            writer.write(linea);
            writer.newLine();
            actual = actual.sig;
        }
    } catch (IOException e) {
        mostrarError("Error al guardar usuarios: " + e.getMessage());
    }
}

public void cargarUsuariosDesdeArchivo(String nombreArchivo) {
    cab = null;

    try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
        String linea;
        while ((linea = reader.readLine()) != null) {
            String[] partes = linea.split(";");
            if (partes.length == 6) {
                Usuarios usuario = new Usuarios(partes[0], partes[1], partes[2], partes[3], partes[4], partes[5]);
                AgregarusuarioSinGuardar(usuario); // evita guardar en cada línea
            }
        }
    } catch (IOException e) {
        System.out.println("Archivo no encontrado o error al leer usuarios.txt: " + e.getMessage());
    }
}

private void AgregarusuarioSinGuardar(Usuarios nuevo) {
    nodo<Usuarios> nuevoNodo = new nodo<>(nuevo);
    if (getVacia()) {
        cab = nuevoNodo;
    } else {
        nodo<Usuarios> p = cab;
        while (p.sig != null) {
            p = p.sig;
        }
        p.sig = nuevoNodo;
        nuevoNodo.ant = p;
    }
}
}