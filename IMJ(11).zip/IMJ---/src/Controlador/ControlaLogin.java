/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.scene.control.*;
import javafx.scene.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.*;
import javafx.stage.Stage;

public class ControlaLogin implements Initializable {


    
    @FXML private TextField txtNombre;
    @FXML private TextField txtApellido;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtCorreoN;
    @FXML private PasswordField txtContrasena;


    @FXML
    private TextField txtCorreo;

    @FXML
    private PasswordField txtPassword;

    private Controlausuarios control = Controlausuarios.getInstancia(); 
    
    @FXML
    private ImageView logoImageView;
    
    @Override
public void initialize(URL location, ResourceBundle resources) {
    URL logoUrl = getClass().getResource("/images/Logo.png");
    if (logoUrl != null && logoImageView != null) {
        logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        System.out.println("Logo cargado correctamente desde: " + logoUrl.toExternalForm());
    } else {
        System.out.println("No se encontró la imagen o el ImageView es null");
    }
}

@FXML

private void iniciarSesion(ActionEvent event) {
    String correo = txtCorreo.getText().trim();
    String clave = txtPassword.getText().trim();

    nodo<Usuarios> usuario = control.BuscarUsuario(correo);

    if (usuario != null && usuario.dato.correo.equals(correo) && usuario.dato.contrasena.equals(clave)) {
        String tipo = usuario.dato.tipo;
        if (tipo.equalsIgnoreCase("admin")) {
            cambiarEscena("/fxml/CatalogoAdm.fxml", event);
        } else if (tipo.equalsIgnoreCase("cliente")) {
            cambiarEscena("/fxml/CatalogoC.fxml", event);
        }
    } else {
        mostrarError("Credenciales incorrectas");
    }
}

    
@FXML
private void crearCuenta(ActionEvent event) {
    boolean creado = control.AddUsuario(txtNombre, txtApellido, txtCorreoN, txtTelefono, txtContrasena);
    if (creado) {
        mostrarMensaje("Cuenta creada correctamente");
        cambiarEscena("/fxml/Loguin.fxml", event); 
    }
}
@FXML
private void ircrearCuenta(ActionEvent event) {
    cambiarEscena("/fxml/Ncuenta.fxml",event);
}

private void cambiarEscena(String rutaFXML, ActionEvent event) {
    try {
        URL fxmlUrl = getClass().getResource(rutaFXML);
        if (fxmlUrl == null) {
            System.out.println("No se encontró el archivo FXML: " + rutaFXML);
            return;
        }

        FXMLLoader loader = new FXMLLoader(fxmlUrl);
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    } catch (IOException e) {
        mostrarError("Error al cargar la vista: " + e.getMessage());
    }
}



    private void mostrarMensaje(String texto) {
        Alert alerta = new Alert(AlertType.INFORMATION);
        alerta.setTitle("Login");
        alerta.setHeaderText(null);
        alerta.setContentText(texto);
        alerta.showAndWait();
    }

    private void mostrarError(String texto) {
        Alert alerta = new Alert(AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(texto);
        alerta.showAndWait();
    }
    
    

@FXML
private void cancelar(ActionEvent event) {
    Volver(event, "/fxml/PagP.fxml");
}

private void Volver(ActionEvent event, String rutaFXML) {
    try {
        URL fxmlUrl = getClass().getResource(rutaFXML);
        if (fxmlUrl == null) {
            System.out.println("No se encontró el archivo FXML: " + rutaFXML);
            return;
        }

        FXMLLoader loader = new FXMLLoader(fxmlUrl);
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    } catch (IOException e) {
        System.out.println("Error al cargar FXML: " + rutaFXML);
        e.printStackTrace();
    }
}

}

