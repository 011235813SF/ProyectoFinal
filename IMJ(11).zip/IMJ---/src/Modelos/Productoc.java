/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

/**
 *
 * @author PC
 */
public class Productoc {

    public String nombreprod, descripcion, rutaimg;
    public int cant, precio;

    public Productoc(String nombreprod,String descripcion, String rutaimg, int cant, int precio) {
        this.nombreprod = nombreprod;
        this.descripcion=descripcion;
        this.rutaimg = rutaimg;
        this.cant = cant;
        this.precio = precio;
    }

}
