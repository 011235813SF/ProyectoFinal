/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;

/**
 *
 * @author PC
 */
public class Direcciones {

    public String direccionentrega, depto, municp, barr, espcf, adci, tipo, nomb, tel;

    public Direcciones(String direccionentrega, String depto, String municp, String barr, String espcf, String adci, String tipo, String nomb, String tel) {
        this.direccionentrega = direccionentrega;
        this.depto = depto;
        this.municp = municp;
        this.barr = barr;
        this.espcf = espcf;
        this.adci = adci;
        this.tipo = tipo;
        this.nomb = nomb;
        this.tel = tel;
    }

}
