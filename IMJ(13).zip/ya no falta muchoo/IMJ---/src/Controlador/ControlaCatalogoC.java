/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.NumberFormat;
import java.util.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ControlaCatalogoC implements Initializable {

    @FXML private ImageView logoImageView;
    @FXML private GridPane grid;
    @FXML private Button PerfilCliente;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        actualizarCatalogo();

        URL logoUrl = getClass().getResource("/images/Logo.png");
        if (logoUrl != null && logoImageView != null) {
            logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        }
    }

    public void actualizarCatalogo() {
        grid.getChildren().clear();

        Controlaprodc.getInstancia().cargarProductosDesdeArchivo("productos.txt");

        nodo<Productoc> actual = Controlaprodc.getInstancia().cab;
        int columnas = 4;
        int fila = 0;
        int col = 0;

        while (actual != null) {
            VBox tarjeta = crearTarjetaProducto(actual.dato);
            grid.add(tarjeta, col, fila);

            col++;
            if (col == columnas) {
                col = 0;
                fila++;
            }

            actual = actual.sig;
        }
    }

    private VBox crearTarjetaProducto(Productoc producto) {
    VBox tarjeta = new VBox(5);
    tarjeta.setPadding(new Insets(10));
    tarjeta.setStyle("-fx-border-color: lightgray; -fx-border-radius: 5; -fx-background-color: white;");
    tarjeta.setAlignment(Pos.CENTER);
    tarjeta.setPrefSize(200, 260);

    ImageView img = new ImageView();
    try {
        File archivo = new File(producto.rutaimg);
        Image imagen = new Image(archivo.toURI().toString());
        img.setImage(imagen);
    } catch (Exception e) {
        System.out.println("No se pudo cargar la imagen: " + producto.rutaimg);
    }
    img.setFitWidth(120);
    img.setFitHeight(120);
    img.setPreserveRatio(true);

    Label nombre = new Label(producto.nombreprod);
    nombre.setStyle("-fx-font-weight: bold; -fx-text-fill: #000066;");

    Label descripcion = new Label(producto.descripcion);
    descripcion.setWrapText(true);

    NumberFormat formato = NumberFormat.getInstance(new Locale("es", "CO"));
    String precioFormateado = formato.format(producto.precio);
    Label precio = new Label("$ " + precioFormateado);

    Button btnAgregar = new Button("Añadir al carrito");
    btnAgregar.setStyle("""
        -fx-background-color: #008080;
        -fx-text-fill: white;
        -fx-font-size: 11px;
        -fx-background-radius: 6;
    """);
    btnAgregar.setPrefSize(100, 25);
    btnAgregar.setOnAction(e -> {
    Carrito item = new Carrito(producto, 1); // ← cantidad inicial
    Controlacarrito.getInstancia().agregarCarrito(item);

    Alert alerta = new Alert(Alert.AlertType.INFORMATION);
    alerta.setHeaderText(null);
    alerta.setContentText("Producto añadido al carrito: " + producto.nombreprod);
    alerta.showAndWait();
});


    Button btnFavorito = new Button("♡");
    btnFavorito.setStyle("""
        -fx-background-color: transparent;
        -fx-font-size: 20px;
        -fx-text-fill: #cc0000;
        -fx-cursor: hand;
    """);
    btnFavorito.setPrefSize(40, 40);
    btnFavorito.setOnAction(e -> {
        Controlafav.getInstancia().agregarFavorito(producto);
        System.out.println("Producto añadido a favoritos: " + producto.nombreprod);
    });

    HBox contenedorBotones = new HBox(10);
    contenedorBotones.setAlignment(Pos.CENTER);
    contenedorBotones.getChildren().addAll(btnAgregar, btnFavorito);

    tarjeta.getChildren().addAll(img, nombre, descripcion, precio, contenedorBotones);

    return tarjeta;
}

    @FXML
    private void ordenarAZ(ActionEvent event) {
        List<Productoc> productos = new ArrayList<>();
        nodo<Productoc> actual = Controlaprodc.getInstancia().getProductos();
        while (actual != null) {
            productos.add(actual.dato);
            actual = actual.sig;
        }

        productos.sort(Comparator.comparing(p -> p.nombreprod.toLowerCase()));

        grid.getChildren().clear();
        int column = 0;
        int row = 0;
        for (Productoc producto : productos) {
            VBox tarjeta = crearTarjetaProducto(producto);
            grid.add(tarjeta, column++, row);
            if (column == 4) {
                column = 0;
                row++;
            }
        }
    }

    @FXML
    private void ordenarPorDefecto(ActionEvent event) {
        actualizarCatalogo();
    }

    @FXML
    private void irAPerfilCliente(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    @FXML
    private void irACarrito(ActionEvent event) {
        cambiarEscena(event, "/fxml/Carrito.fxml");
    }

    @FXML
    private void irAFavoritos(ActionEvent event) {
        cambiarEscena(event, "/fxml/ListaDeseos.fxml");
    }

    
    @FXML
    private void irAMisCompras(ActionEvent event) {
        cambiarEscena(event, "/fxml/Compras.fxml");
    }
    
    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
