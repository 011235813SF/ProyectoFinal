/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Jesu
 */
public class ControlaCompras {
        @FXML
    private void volerAtras(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }
    @FXML
private void IrAtrasCompras(ActionEvent event) {
    cambiarEscena(event, "/fxml/CatalogoC.fxml");
}

@FXML
private void IrAtrasAPerfil(ActionEvent event) {
    cambiarEscena(event, "/fxml/PerfilClient.fxml");
}

@FXML
private void IrAFavoritos(ActionEvent event) {
    cambiarEscena(event, "/fxml/ListaDeseos.fxml");
}

@FXML
private void IrACarrito(ActionEvent event) {
    cambiarEscena(event, "/fxml/Carrito.fxml");
}


    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
