/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.*;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class Controlacarrito implements Initializable {

    private static Controlacarrito instancia;

    public static Controlacarrito getInstancia() {
        if (instancia == null) {
            instancia = new Controlacarrito();
        }
        return instancia;
    }

    public static nodo<Carrito> cab = null;

    public Controlacarrito() {
        cab = null;
        cargarCarritoDesdeArchivo("carrito.txt");
    }

    public boolean getVacia() {
        return cab == null;
    }

    public void agregarCarrito(Carrito item) {
        if (!getVacia()) {
            nodo<Carrito> actual = cab;
            do {
                if (actual.dato.producto.nombreprod.trim().equalsIgnoreCase(item.producto.nombreprod.trim())) {
                    mostrarError("Error: El producto ya está en el carrito");
                    return;
                }
                actual = actual.sig;
            } while (actual != cab);
        }

        nodo<Carrito> nuevo = new nodo<>(item);

        if (getVacia()) {
            cab = nuevo;
            cab.sig = cab;
            cab.ant = cab;
        } else {
            nodo<Carrito> ultimo = cab.ant;
            nuevo.sig = cab;
            nuevo.ant = ultimo;
            cab.ant = nuevo;
            ultimo.sig = nuevo;
        }

        guardarCarritoEnArchivo("carrito.txt");
    }

    private void agregarCarritoSinGuardar(Carrito item) {
        nodo<Carrito> nuevo = new nodo<>(item);

        if (getVacia()) {
            cab = nuevo;
            cab.sig = cab;
            cab.ant = cab;
        } else {
            nodo<Carrito> ultimo = cab.ant;
            nuevo.sig = cab;
            nuevo.ant = ultimo;
            cab.ant = nuevo;
            ultimo.sig = nuevo;
        }
    }

    public void guardarCarritoEnArchivo(String nombreArchivo) {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter(nombreArchivo))) {
        if (!getVacia()) {
            nodo<Carrito> actual = cab;
            do {
                Carrito c = actual.dato;
                Productoc p = c.producto;
                String linea = String.join(";",
                        p.nombreprod,
                        p.descripcion,
                        p.rutaimg,
                        String.valueOf(p.precio),
                        String.valueOf(c.cant));
                writer.write(linea);
                writer.newLine();
                actual = actual.sig;
            } while (actual != cab);
        }
      
    } catch (IOException e) {
        mostrarError("Error al guardar carrito: " + e.getMessage());
    }
}

    
 

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    @FXML
    private VBox contenedorProductos;

    @FXML
    private ImageView logoImageView;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        URL logoUrl = getClass().getResource("/images/Logo.png");
        if (logoUrl != null && logoImageView != null) {
            logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        }
        renderizarCarrito();
    }

    public void renderizarCarrito() {
        if (contenedorProductos == null) return;

        contenedorProductos.getChildren().clear();

        if (getVacia()) {
            Label vacio = new Label("El carrito está vacío.");
            vacio.setStyle("-fx-font-size: 16px; -fx-text-fill: gray;");
            VBox centrado = new VBox(vacio);
            centrado.setAlignment(Pos.CENTER);
            VBox.setVgrow(centrado, Priority.ALWAYS);
            contenedorProductos.getChildren().add(centrado);
            return;
        }

        nodo<Carrito> actual = cab;
        do {
            Carrito item = actual.dato;

            HBox tarjeta = new HBox(10);
            tarjeta.setPadding(new Insets(10));
            tarjeta.setAlignment(Pos.CENTER_LEFT);
            tarjeta.setStyle("-fx-background-color: white; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10;");

            ImageView imagen = new ImageView();
            try {
                File archivo = new File(item.producto.rutaimg);
                if (archivo.exists()) {
                    imagen.setImage(new Image(archivo.toURI().toString()));
                } else {
                    imagen.setImage(new Image(getClass().getResourceAsStream("/img/placeholder.png")));
                }
            } catch (Exception e) {
                imagen.setImage(new Image(getClass().getResourceAsStream("/img/placeholder.png")));
            }

            imagen.setFitWidth(50);
            imagen.setFitHeight(50);
            imagen.setPreserveRatio(true);

            VBox contenido = new VBox(5);
            Label nombre = new Label(item.producto.nombreprod);
            nombre.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");

            Spinner<Integer> spinnerCantidad = new Spinner<>(1, 99, item.cant);
            spinnerCantidad.setEditable(true);

            HBox cantidadBox = new HBox(5, new Label("Cantidad:"), spinnerCantidad);
            cantidadBox.setAlignment(Pos.CENTER_LEFT);

            TextField subtotalField = new TextField(String.format("$ %,.2f", item.getSubtotal()));
            subtotalField.setEditable(false);
            subtotalField.setStyle("-fx-background-color: transparent; -fx-border-color: transparent;");

            spinnerCantidad.valueProperty().addListener((obs, oldVal, newVal) -> {
    item.cant = newVal;
    subtotalField.setText(String.format("$ %,.2f", item.getSubtotal())); // ✅ corregido
    guardarCarritoEnArchivo("carrito.txt");
    actualizarTotales();
});

            contenido.getChildren().addAll(nombre, cantidadBox, subtotalField);

            Button btnEliminar = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/images/Eliminar.png"))));
            btnEliminar.setStyle("-fx-background-color: transparent;");
            ((ImageView) btnEliminar.getGraphic()).setFitWidth(20);
            ((ImageView) btnEliminar.getGraphic()).setFitHeight(20);
            btnEliminar.setOnAction(e -> {
                eliminar(item.producto.nombreprod);
                renderizarCarrito();
                guardarCarritoEnArchivo("carrito.txt");
            });

            HBox.setHgrow(contenido, Priority.ALWAYS);
            tarjeta.getChildren().addAll(imagen, contenido, btnEliminar);

            contenedorProductos.getChildren().add(tarjeta);

            actual = actual.sig;
        } while (actual != cab);
        
        double total = 0;

if (!getVacia()) {
    do {
        total += actual.dato.getSubtotal();
        actual = actual.sig;
    } while (actual != cab);
}

lblSubtotal.setText(String.format("$ %, .2f", total));
lblTotal.setText(String.format("$ %, .2f", total));
    }

    public boolean eliminar(String nombreprod) {
    if (getVacia()) return false;

    nodo<Carrito> actual = cab;
    do {
        if (actual.dato.producto.nombreprod.trim().equalsIgnoreCase(nombreprod.trim())) {
            if (actual == cab && cab.sig == cab) {
                cab = null;
            } else {
                actual.ant.sig = actual.sig;
                actual.sig.ant = actual.ant;
                if (actual == cab) {
                    cab = actual.sig;
                }
            }

            break; // sale del bucle
        }
        actual = actual.sig;
    } while (actual != cab);

    guardarCarritoEnArchivo("carrito.txt"); // Siempre guarda después de intentar eliminar
    return true;
}

    public void cargarCarritoDesdeArchivo(String nombreArchivo) {
    cab = null;
    try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {
        String linea;
        while ((linea = reader.readLine()) != null) {
            String[] partes = linea.split(";");
            if (partes.length == 5) {
                String nombre = partes[0];
                String descripcion = partes[1];
                String rutaImg = partes[2];
                int precio = Integer.parseInt(partes[3]);
                int cantidad = Integer.parseInt(partes[4]);

                Productoc p = new Productoc(nombre, descripcion, rutaImg, cantidad, precio);
                Carrito item = new Carrito(p, cantidad);
                agregarCarritoSinGuardar(item);
            }
        }
    } catch (IOException e) {
        System.out.println("Error al cargar carrito: " + e.getMessage());
    }
}
    
    @FXML
    private void IrAtrasCarrito(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoC.fxml");
    }

    @FXML
    private void IrACatalogo(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoC.fxml");
    }
    
    @FXML
    private void IrAPerfil(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    @FXML
private Label lblSubtotal;

@FXML
private Label lblTotal;


private void actualizarTotales() {
    double total = 0;

    if (!getVacia()) {
        nodo<Carrito> actual = cab;
        do {
            total += actual.dato.getSubtotal();
            actual = actual.sig;
        } while (actual != cab);
    }

    lblSubtotal.setText(String.format("$ %, .2f", total));
    lblTotal.setText(String.format("$ %, .2f", total));
}

    
}