/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import javafx.scene.control.*;

/**
 *
 * @author PC
 */
public class Controlaprodc {
 private static Controlaprodc instancia;

    public static Controlaprodc getInstancia() {
        if (instancia == null) {
            instancia = new Controlaprodc();
        }
        return instancia;
    }
    
    public nodo<Productoc> cab;

    public boolean getVacia() {
        return cab == null ? true : false;
    }

    public int getTamanoLista() {
        int contador = 0;
        nodo<Productoc> actual = cab;
        while (actual != null) {
            contador++;
            actual = actual.sig;
        }
        return contador;
    }

    public nodo<Productoc> getUltimo() {
        if (cab == null) {
            return null;
        }
        nodo<Productoc> actual = cab;
        while (actual.sig != null) {
            actual = actual.sig;
        }
        return actual;
    }

    public nodo<Productoc> BuscaProdxN(String nombre) {
        nodo<Productoc> actual = cab;
        while (actual != null) {
            if (actual.dato.nombreprod.equals(nombre)) {
                return actual;
            }
            actual = actual.sig;
        }
        return null;

    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    public boolean AddProducto(TextField nomb, TextField desc, TextField cant, TextField prec, TextField ruti) {
        try {

            if (nomb.getText().trim().isEmpty() || desc.getText().trim().isEmpty()
                    || cant.getText().trim().isEmpty() || prec.getText().trim().isEmpty()
                    || ruti.getText().trim().isEmpty()) {
                mostrarError("¡Error! Debe llenar todos los campos.");
                return false;
            }

            String nombre = nomb.getText().trim();
            String descripcion = desc.getText().trim();
            String cantidadStr = cant.getText().trim();
            String precioStr = prec.getText().trim();
            String rutaimagen = ruti.getText().trim();

            int cantidad;
            int precio;
            try {
                cantidad = Integer.parseInt(cantidadStr);
                precio = Integer.parseInt(precioStr);
            } catch (NumberFormatException e) {
                mostrarError("Error: El precio y la cantidad deben ser números enteros.");
                return false;
            }

            nodo<Productoc> existente = BuscaProdxN(nombre);
            if (existente != null) {
                mostrarError("Error: El producto ya existe.");
                return false;
            }

            Productoc nuevo = new Productoc(nombre, descripcion, rutaimagen, cantidad, precio);
                      
            AgregarProducto(nuevo);
            
            nomb.setText("");
            desc.setText("");
            cant.setText("");
            prec.setText("");

            return true;

        } catch (Exception e) {
            mostrarError("Ocurrió un error inesperado: " + e.getMessage());
            return false;
        }
    }

    public void AgregarProducto(Productoc u) {
        nodo<Productoc> nuevo = new nodo<>(u);
        if (cab == null) {
            cab = nuevo;
        } else {
            nodo<Productoc> ultimo = getUltimo();
            ultimo.sig = nuevo;
        }
    }

    public void ordenarProductosAZ() {
        if (cab == null || cab.sig == null) {
            return; 
        }
        nodo<Productoc> actual, siguiente;
        for (actual = cab; actual.sig != null; actual = actual.sig) {
            for (siguiente = actual.sig; siguiente != null; siguiente = siguiente.sig) {
                if (actual.dato.nombreprod.compareToIgnoreCase(siguiente.dato.nombreprod) > 0) {
                    // Intercambiar productos
                    Productoc temp = actual.dato;
                    actual.dato = siguiente.dato;
                    siguiente.dato = temp;
                }
            }
        }
    }

}
