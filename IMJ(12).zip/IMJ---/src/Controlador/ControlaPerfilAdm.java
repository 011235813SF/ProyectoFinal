/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author Jesu
 */

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ControlaPerfilAdm {

    @FXML
    private void cerrarSesion(ActionEvent event) {
        cambiarEscena(event, "/fxml/Loguin.fxml");
    }

    @FXML
    private void irAAgregar(ActionEvent event) {
        cambiarEscena(event, "/fxml/Agregar.fxml");
    }

    @FXML
    private void irCatalogo(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoAdm.fxml");
    }

    @FXML
    private void editarProducto(ActionEvent event) {
        cambiarEscena(event, "/fxml/Editar.fxml");
    }
    
    @FXML
    private void irEstadistica(ActionEvent event) {
        cambiarEscena(event, "/fxml/Estadisticas.fxml");
    }
    
    @FXML
    private void datosAdmin(ActionEvent event) {
        cambiarEscena(event, "/fxml/DatosCuentaAdm.fxml");
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
