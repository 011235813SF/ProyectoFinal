/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Modelos.*;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Controlaprodc {
    private static Controlaprodc instancia;
    public nodo<Productoc> cab;

    // Campos enlazados desde el FXML
    @FXML private TextField nomb;
    @FXML private TextField desc;
    @FXML private TextField cant;
    @FXML private TextField prec;
    @FXML private TextField buscarField;
    
    @FXML
    public void initialize() {
    cargarProductosDesdeArchivo("productos.txt");
}


    public static Controlaprodc getInstancia() {
        if (instancia == null) {
            instancia = new Controlaprodc();
        }
        return instancia;
    }

    public boolean getVacia() {
        return cab == null;
    }

    public nodo<Productoc> getProductos() {
        return cab;
    }

    public int getTamanoLista() {
        int contador = 0;
        nodo<Productoc> actual = cab;
        while (actual != null) {
            contador++;
            actual = actual.sig;
        }
        return contador;
    }

    public nodo<Productoc> getUltimo() {
        nodo<Productoc> actual = cab;
        if (actual == null) return null;
        while (actual.sig != null) {
            actual = actual.sig;
        }
        return actual;
    }

    public nodo<Productoc> BuscaProdxN(String nombre) {
        nodo<Productoc> actual = cab;
        while (actual != null) {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombre)) {
                return actual;
            }
            actual = actual.sig;
        }
        return null;
    }

    public void mostrarError(String mensaje) {
        Alert alerta = new Alert(Alert.AlertType.ERROR);
        alerta.setTitle("Error");
        alerta.setHeaderText(null);
        alerta.setContentText(mensaje);
        alerta.showAndWait();
    }

    public void mostrarMensaje(String texto) {
        Alert alerta = new Alert(Alert.AlertType.INFORMATION);
        alerta.setHeaderText(null);
        alerta.setContentText(texto);
        alerta.showAndWait();
    }

    public void AgregarProducto(Productoc u) {
        nodo<Productoc> nuevo = new nodo<>(u);
        if (cab == null) {
            cab = nuevo;
        } else {
            getUltimo().sig = nuevo;
        }
    }

    public boolean AddProducto(TextField nomb, TextField desc, TextField cant, TextField prec, File imagenSeleccionada) {
        try {
            if (nomb.getText().isBlank() || desc.getText().isBlank() || cant.getText().isBlank() || prec.getText().isBlank() || imagenSeleccionada == null) {
                mostrarError("¡Error! Debe llenar todos los campos y seleccionar una imagen.");
                return false;
            }

            String nombre = nomb.getText().trim();
            String descripcion = desc.getText().trim();
            int cantidad, precio;

            try {
                cantidad = Integer.parseInt(cant.getText().trim());
                precio = Integer.parseInt(prec.getText().replace(".", "").trim());
            } catch (NumberFormatException e) {
                mostrarError("El precio y la cantidad deben ser números enteros.");
                return false;
            }

            if (BuscaProdxN(nombre) != null) {
                mostrarError("El producto ya existe.");
                return false;
            }

            File carpeta = new File("imagenesProductos");
            if (!carpeta.exists()) carpeta.mkdirs();

            File destino = new File(carpeta, imagenSeleccionada.getName());
            Files.copy(imagenSeleccionada.toPath(), destino.toPath(), StandardCopyOption.REPLACE_EXISTING);
            String rutaImagen = "imagenesProductos/" + destino.getName();

            Productoc nuevo = new Productoc(nombre, descripcion, rutaImagen, cantidad, precio);
            AgregarProducto(nuevo);
            guardarProductosEnArchivo("productos.txt");

            nomb.setText("");
            desc.setText("");
            cant.setText("");
            prec.setText("");

            return true;

        } catch (Exception e) {
            mostrarError("Error inesperado: " + e.getMessage());
            return false;
        }
    }

    public boolean editarProducto(String nombreOriginal, TextField nuevoNombre, TextField nuevaDesc, TextField nuevaCant, TextField nuevoPrec, File nuevaRutaImg) {
        try {
            nodo<Productoc> productoNodo = BuscaProdxN(nombreOriginal);
            if (productoNodo == null) {
                mostrarError("El producto no existe.");
                return false;
            }

            if (nuevoNombre.getText().trim().isEmpty() || nuevaDesc.getText().trim().isEmpty() || nuevaCant.getText().trim().isEmpty() || nuevoPrec.getText().trim().isEmpty()) {
                mostrarError("Debe llenar todos los campos obligatorios.");
                return false;
            }

            int cantidad = Integer.parseInt(nuevaCant.getText().replace(".", "").trim());
            int precio = Integer.parseInt(nuevoPrec.getText().replace(".", "").trim());

            productoNodo.dato.nombreprod = nuevoNombre.getText().trim();
            productoNodo.dato.descripcion = nuevaDesc.getText().trim();
            productoNodo.dato.cant = cantidad;
            productoNodo.dato.precio = precio;

            if (nuevaRutaImg != null && !nuevaRutaImg.getPath().isBlank()) {
                productoNodo.dato.rutaimg = nuevaRutaImg.getPath();
            }

            mostrarMensaje("Producto actualizado correctamente.");
            return true;

        } catch (Exception e) {
            mostrarError("Error al editar producto: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarProducto(String nombre) {
        if (cab == null) {
            mostrarError("La lista de productos está vacía.");
            return false;
        }

        if (cab.dato.nombreprod.equalsIgnoreCase(nombre)) {
            cab = cab.sig;
            mostrarMensaje("Producto eliminado correctamente.");
            return true;
        }

        nodo<Productoc> anterior = cab;
        nodo<Productoc> actual = cab.sig;

        while (actual != null) {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombre)) {
                anterior.sig = actual.sig;
                mostrarMensaje("Producto eliminado correctamente.");
                return true;
            }
            anterior = actual;
            actual = actual.sig;
        }

        mostrarError("No se encontró un producto con ese nombre.");
        return false;
    }

    public void ordenarProductosAZ() {
        if (cab == null || cab.sig == null) return;

        for (nodo<Productoc> actual = cab; actual.sig != null; actual = actual.sig) {
            for (nodo<Productoc> siguiente = actual.sig; siguiente != null; siguiente = siguiente.sig) {
                if (actual.dato.nombreprod.compareToIgnoreCase(siguiente.dato.nombreprod) > 0) {
                    Productoc temp = actual.dato;
                    actual.dato = siguiente.dato;
                    siguiente.dato = temp;
                }
            }
        }
    }

    public void guardarProductosEnArchivo(String rutaArchivo) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(rutaArchivo))) {
            nodo<Productoc> actual = cab;
            while (actual != null) {
                Productoc p = actual.dato;
                String linea = p.nombreprod + "|" + p.descripcion + "|" + p.rutaimg + "|" + p.cant + "|" + p.precio;
                writer.write(linea);
                writer.newLine();
                actual = actual.sig;
            }
        } catch (IOException e) {
            mostrarError("Error al guardar productos: " + e.getMessage());
        }
    }

    public void cargarProductosDesdeArchivo(String rutaArchivo) {
        cab = null;
        try (BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split("\\|");
                if (partes.length == 5) {
                    String nombre = partes[0];
                    String descripcion = partes[1];
                    String rutaImg = partes[2];
                    int cantidad = Integer.parseInt(partes[3]);
                    int precio = Integer.parseInt(partes[4]);
                    Productoc p = new Productoc(nombre, descripcion, rutaImg, cantidad, precio);
                    AgregarProducto(p);
                }
            }
        } catch (IOException e) {
            mostrarError("Error al cargar productos: " + e.getMessage());
        }
    }

    @FXML
    private void IrAEditar(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilAdm.fxml");
    }

    @FXML
    private void ActualizarProducto(ActionEvent event) {
        String nombreOriginal = buscarField.getText().trim();
        if (nombreOriginal.isEmpty()) {
            mostrarError("Ingrese el nombre del producto a actualizar.");
            return;
        }

        editarProducto(nombreOriginal, nomb, desc, cant, prec, null);
    }

    @FXML
    private void EliminarProducto(ActionEvent event) {
        String nombre = buscarField.getText().trim();
        if (nombre.isEmpty()) {
            mostrarError("Ingrese el nombre del producto a eliminar.");
            return;
        }

        eliminarProducto(nombre);
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
}
