/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Controlador;

import Modelos.*;
import javafx.event.ActionEvent;
import javafx.fxml.*;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.text.NumberFormat;
import java.util.*;

public class Controlafav implements Initializable {
    private static Controlafav dataInstance;
    private static final String FAVORITOS_FILE = "favoritos.txt";

    public static Controlafav getInstancia() {
        if (dataInstance == null) {
            dataInstance = new Controlafav();
            dataInstance.cargarFavoritos();
        }
        return dataInstance;
    }

    public nodo<Productoc> cab;

    public Controlafav() {}

    @FXML private ImageView logoImageView;
    @FXML private VBox contenedorFavoritos;

    public boolean getVacia() {
        return this.cab == null;
    }

    public void agregarFavorito(Productoc producto) {
        Controlafav currentDataInstance = Controlafav.getInstancia();
        if (currentDataInstance.yaExiste(producto.nombreprod)) {
            mostrarAlerta("Información", "Este producto ya está en la lista de favoritos.");
            return;
        }

        nodo<Productoc> nuevo = new nodo<>(producto);

        if (currentDataInstance.getVacia()) {
            currentDataInstance.cab = nuevo;
            currentDataInstance.cab.sig = currentDataInstance.cab;
            currentDataInstance.cab.ant = currentDataInstance.cab;
        } else {
            nodo<Productoc> ultimo = currentDataInstance.cab.ant;
            nuevo.sig = currentDataInstance.cab;
            nuevo.ant = ultimo;
            currentDataInstance.cab.ant = nuevo;
            ultimo.sig = nuevo;
        }
        mostrarAlerta("Éxito", "Producto agregado a favoritos.");
        guardarFavoritos();
    }

    public boolean yaExiste(String nombreprod) {
        nodo<Productoc> currentCab = this.cab;
        if (currentCab == null) return false;

        nodo<Productoc> actual = currentCab;
        do {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombreprod)) {
                return true;
            }
            actual = actual.sig;
        } while (actual != currentCab);

        return false;
    }

    public boolean eliminarFavorito(String nombreprod) {
        Controlafav currentDataInstance = Controlafav.getInstancia();
        if (currentDataInstance.getVacia()) return false;

        nodo<Productoc> actual = currentDataInstance.cab;
        boolean removed = false;
        do {
            if (actual.dato.nombreprod.equalsIgnoreCase(nombreprod)) {
                if (actual == currentDataInstance.cab && currentDataInstance.cab.sig == currentDataInstance.cab) {
                    currentDataInstance.cab = null;
                } else {
                    actual.ant.sig = actual.sig;
                    actual.sig.ant = actual.ant;
                    if (actual == currentDataInstance.cab) {
                        currentDataInstance.cab = actual.sig;
                    }
                }
                removed = true;
                break;
            }
            actual = actual.sig;
        } while (actual != currentDataInstance.cab);

        if (removed) {
            mostrarAlerta("Éxito", "Producto eliminado de favoritos.");
            guardarFavoritos();
        } else {
            mostrarAlerta("Error", "No se pudo encontrar el producto en favoritos.");
        }
        return removed;
    }

    public int contarFavoritos() {
        if (getVacia()) return 0;

        int contador = 0;
        nodo<Productoc> actual = this.cab;
        do {
            contador++;
            actual = actual.sig;
        } while (actual != this.cab);

        return contador;
    }

    public void vaciarFavoritos() {
        this.cab = null;
        guardarFavoritos();
    }

    private void guardarFavoritos() {
        List<String> lineas = new ArrayList<>();
        if (!getVacia()) {
            nodo<Productoc> actual = this.cab;
            do {
                lineas.add(actual.dato.toCsvString());
                actual = actual.sig;
            } while (actual != this.cab);
        }

        try {
            Files.write(Paths.get(FAVORITOS_FILE), lineas);
        } catch (IOException e) {
            System.err.println("Error al guardar favoritos: " + e.getMessage());
        }
    }

    private void cargarFavoritos() {
        this.cab = null;
        File file = new File(FAVORITOS_FILE);
        if (!file.exists()) return;

        try {
            List<String> lineas = Files.readAllLines(Paths.get(FAVORITOS_FILE));
            for (String linea : lineas) {
                Productoc prod = Productoc.fromCsvString(linea);
                if (prod != null) {
                    nodo<Productoc> nuevo = new nodo<>(prod);
                    if (this.cab == null) {
                        this.cab = nuevo;
                        this.cab.sig = this.cab;
                        this.cab.ant = this.cab;
                    } else {
                        nodo<Productoc> ultimo = this.cab.ant;
                        nuevo.sig = this.cab;
                        nuevo.ant = ultimo;
                        this.cab.ant = nuevo;
                        ultimo.sig = nuevo;
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error al cargar favoritos: " + e.getMessage());
        }
    }

    public void renderizarFavoritos() {
        if (contenedorFavoritos == null) return;

        contenedorFavoritos.getChildren().clear();

        Controlafav currentDataInstance = Controlafav.getInstancia();

        if (currentDataInstance.getVacia()) {
            Label noFavoritesLabel = new Label("No tienes productos en favoritos.");
            noFavoritesLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: gray;");
            VBox centeredContent = new VBox(noFavoritesLabel);
            centeredContent.setAlignment(Pos.CENTER);
            VBox.setVgrow(centeredContent, Priority.ALWAYS);
            contenedorFavoritos.getChildren().add(centeredContent);
            return;
        }

        nodo<Productoc> actual = currentDataInstance.cab;
        do {
            Productoc prod = actual.dato;

            HBox tarjeta = new HBox(10);
            tarjeta.setPadding(new Insets(10));
            tarjeta.setAlignment(Pos.CENTER_LEFT);
            tarjeta.setStyle("-fx-background-color: white; -fx-border-color: lightgray; -fx-border-radius: 10; -fx-background-radius: 10;");

            ImageView imagen = new ImageView();
                if (prod.rutaimg != null && !prod.rutaimg.isEmpty()) {
    File archivoImagen = new File(prod.rutaimg);
    if (archivoImagen.exists()) {
        Image image = new Image(archivoImagen.toURI().toString());
        imagen.setImage(image);
    } else {
        System.out.println("No se encontró la imagen: " + prod.rutaimg);
        // Opcional: poner una imagen por defecto o dejar vacío
        imagen.setImage(null);
    }
} else {
    System.out.println("Ruta de imagen nula o vacía para producto: " + prod.nombreprod);
    imagen.setImage(null);
}
            

            imagen.setFitWidth(50);
            imagen.setFitHeight(50);
            imagen.setPreserveRatio(true);

            VBox contenido = new VBox(5);
            Label nombre = new Label(prod.nombreprod);
            nombre.setStyle("-fx-font-weight: bold; -fx-font-size: 14;");

            Spinner<Integer> spinnerCantidad = new Spinner<>(1, 99, 1);
            spinnerCantidad.setEditable(true);

            HBox cantidadBox = new HBox(5, new Label("Cantidad: "), spinnerCantidad);
            cantidadBox.setAlignment(Pos.CENTER_LEFT);

            NumberFormat formatoMoneda = NumberFormat.getCurrencyInstance(new Locale("es", "CO"));
            Label precio = new Label(formatoMoneda.format(prod.precio));
            precio.setStyle("-fx-font-weight: bold; -fx-text-fill: #008080;");

            contenido.getChildren().addAll(nombre, precio, cantidadBox);

            Button btnAgregarCarrito = new Button("Agregar al carrito");
            btnAgregarCarrito.setStyle("-fx-background-color: #00796B; -fx-text-fill: white;");
            btnAgregarCarrito.setOnAction(e -> {
                Carrito nuevo = new Carrito(prod, spinnerCantidad.getValue());
                Controlacarrito.getInstancia().agregarCarrito(nuevo);
                mostrarAlerta("Éxito", "Producto añadido al carrito.");
            });

            Button btnEliminar = new Button("", new ImageView(new Image(getClass().getResourceAsStream("/images/Eliminar.png"))));
            btnEliminar.setStyle("-fx-background-color: transparent;");
            ((ImageView) btnEliminar.getGraphic()).setFitWidth(20);
            ((ImageView) btnEliminar.getGraphic()).setFitHeight(20);
            btnEliminar.setOnAction(e -> {
                Controlafav.getInstancia().eliminarFavorito(prod.nombreprod);
                renderizarFavoritos();
            });

            VBox botones = new VBox(5, btnEliminar, btnAgregarCarrito);
            botones.setAlignment(Pos.CENTER_RIGHT);

            HBox.setHgrow(contenido, Priority.ALWAYS);
            tarjeta.getChildren().addAll(imagen, contenido, botones);
            VBox.setMargin(tarjeta, new Insets(5, 0, 5, 0));
            contenedorFavoritos.getChildren().add(tarjeta);

            actual = actual.sig;
        } while (actual != currentDataInstance.cab);
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        URL logoUrl = getClass().getResource("/images/Logo.png");
        if (logoUrl != null && logoImageView != null) {
            logoImageView.setImage(new Image(logoUrl.toExternalForm()));
        }
        renderizarFavoritos();
    }

    @FXML private void irAtrasFav(ActionEvent event) {
        cambiarEscena(event, "/fxml/CatalogoC.fxml");
    }

    @FXML private void irACarritoFav(ActionEvent event) {
        cambiarEscena(event, "/fxml/Carrito.fxml");
    }

    @FXML private void irAPerfilCli(ActionEvent event) {
        cambiarEscena(event, "/fxml/PerfilClient.fxml");
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) return;

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.out.println("Error al cargar FXML: " + rutaFXML);
            e.printStackTrace();
        }
    }
}
