/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author PC
 */
public class ControlaPerfilCliente {
        @FXML
    private void cerrarSesion(ActionEvent event) {
        cambiarEscena(event, "/fxml/Loguin.fxml");  }


    
        @FXML
    private void irCatalogo(ActionEvent event) {
    cambiarEscena(event, "/fxml/CatalogoC.fxml");
}
        @FXML
    private void irADireccion(ActionEvent event) {
    cambiarEscena(event, "/fxml/Ndirección.fxml");
}

    
        @FXML
    private void irACompras(ActionEvent event) {
    cambiarEscena(event, "/fxml/Compras.fxml");
}
    
        @FXML
    private void irDatosC(ActionEvent event) {
    cambiarEscena(event, "/fxml/DatosCuenta.fxml");
}

    private void cambiarEscena(ActionEvent event, String rutaFXML) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(rutaFXML));
            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
}
