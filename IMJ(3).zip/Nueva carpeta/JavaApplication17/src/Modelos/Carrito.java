/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelos;


/**
 *
 * @author PC
 */
public class Carrito {

    public Productoc producto;
    public int cant;

    public Carrito(Productoc producto, int cant) {
        this.producto = producto;
        this.cant = cant;
    }

}
